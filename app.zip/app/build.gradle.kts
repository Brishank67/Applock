plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.dishaonline.applock"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.dishaonline.applock"
        minSdk = 28
        targetSdk = 34
        versionCode = 3
        versionName = "1.0.0"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("applock-test.keystore")
            storePassword = "android"
            keyAlias = "applock"
            keyPassword = "android"
        }
        create("release") {
            storeFile = file("arushield-release.keystore")
            storePassword = System.getenv("KEYSTORE_PASSWORD")
            keyAlias = "arushield"
            keyPassword = System.getenv("KEYSTORE_PASSWORD")
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
