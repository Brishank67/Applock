package com.dishaonline.applock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class WatchService : Service() {

    companion object {
        @Volatile var unlockedPkg: String? = null
        @Volatile var lockShowing = false

        fun start(c: Context) {
            val i = Intent(c, WatchService::class.java)
            c.startForegroundService(i)
        }
    }

    private val handler = Handler(Looper.getMainLooper())

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { unlockedPkg = null }
    }

    private val tick = object : Runnable {
        override fun run() {
            try { check() } catch (e: Exception) { }
            handler.postDelayed(this, 400)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("watch", "App Lock", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "watch")
            .setContentTitle("App Lock chalu hai")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { unregisterReceiver(screenOff) } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun check() {
        val now = System.currentTimeMillis()
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val ev = usm.queryEvents(now - 3000, now)
        val e = UsageEvents.Event()
        var latest: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) latest = e.packageName
        }
        if (latest == null || latest == packageName) return
        if (latest != unlockedPkg) unlockedPkg = null
        if (Store.enabled(this) && latest in Store.locked(this) && latest != unlockedPkg && !lockShowing) {
            lockShowing = true
            val i = Intent(this, LockActivity::class.java)
                .putExtra("pkg", latest)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            startActivity(i)
        }
    }
}
