package com.dishaonline.applock

import android.content.Context
import java.security.MessageDigest

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun hash(p: String): String =
        MessageDigest.getInstance("SHA-256").digest(("disha:" + p).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(c: Context) = sp(c).getString("pin", null) != null
    fun setPin(c: Context, p: String) = sp(c).edit().putString("pin", hash(p)).apply()
    fun checkPin(c: Context, p: String) = sp(c).getString("pin", null) == hash(p)

    fun locked(c: Context): Set<String> = sp(c).getStringSet("locked", emptySet()) ?: emptySet()
    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val s = locked(c).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("locked", s).apply()
    }

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun finger(c: Context) = sp(c).getBoolean("finger", true)
    fun setFinger(c: Context, v: Boolean) = sp(c).edit().putBoolean("finger", v).apply()
}
