package com.dishaonline.applock

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("applock_v2", Context.MODE_PRIVATE)

    private fun salt(c: Context): String {
        val existing = sp(c).getString("salt", null)
        if (existing != null) return existing
        val s = UUID.randomUUID().toString()
        sp(c).edit().putString("salt", s).apply()
        return s
    }

    private fun hash(c: Context, p: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt(c) + ":" + p).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(c: Context) = sp(c).getString("pin", null) != null
    fun setPin(c: Context, p: String) { sp(c).edit().putString("pin", hash(c, p)).apply() }
    fun checkPin(c: Context, p: String) = sp(c).getString("pin", null) == hash(c, p)

    fun questionIndex(c: Context) = sp(c).getInt("qi", -1)
    fun setQuestion(c: Context, i: Int, answer: String) {
        sp(c).edit().putInt("qi", i).putString("qa", hash(c, answer.trim().lowercase())).apply()
    }
    fun checkAnswer(c: Context, a: String) = sp(c).getString("qa", null) == hash(c, a.trim().lowercase())

    fun locked(c: Context): Set<String> = sp(c).getStringSet("locked", emptySet()) ?: emptySet()
    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val s = locked(c).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("locked", s).apply()
    }

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("enabled", v).apply() }

    fun finger(c: Context) = sp(c).getBoolean("finger", true)
    fun setFinger(c: Context, v: Boolean) { sp(c).edit().putBoolean("finger", v).apply() }

    fun theme(c: Context) = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) { sp(c).edit().putInt("theme", v).apply() }

    fun autolock(c: Context) = sp(c).getInt("autolock", 0)
    fun setAutolock(c: Context, v: Int) { sp(c).edit().putInt("autolock", v).apply() }

    fun onboarded(c: Context) = sp(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) { sp(c).edit().putBoolean("onboarded", v).apply() }
}
