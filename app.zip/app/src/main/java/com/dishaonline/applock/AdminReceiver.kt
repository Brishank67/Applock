package com.dishaonline.applock

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
