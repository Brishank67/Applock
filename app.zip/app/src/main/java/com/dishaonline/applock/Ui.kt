package com.dishaonline.applock

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object Palette {
    class T(val name: String, val a: Int, val b: Int)

    val BG = 0xFF0F1226.toInt()
    val CARD = 0xFF1B1F3B.toInt()
    val LINE = 0xFF2A2F55.toInt()
    val MUTED = 0xFFA9B0D6.toInt()
    val GREEN = 0xFF1F8A5B.toInt()
    val SOFT = 0xFFB9A6FF.toInt()

    val list = listOf(
        T("Violet", 0xFF7C4DFF.toInt(), 0xFF3D5AFE.toInt()),
        T("Ocean", 0xFF00B4D8.toInt(), 0xFF0077B6.toInt()),
        T("Forest", 0xFF2E9E6B.toInt(), 0xFF14532D.toInt()),
        T("Sunset", 0xFFF59E0B.toInt(), 0xFFB91C1C.toInt()),
        T("Rose", 0xFFEC4899.toInt(), 0xFF7E22CE.toInt()),
        T("Midnight", 0xFF475569.toInt(), 0xFF0F172A.toInt())
    )

    fun cur(c: Context): T = list[Store.theme(c).coerceIn(0, list.size - 1)]

    fun blend(x: Int, y: Int, f: Float): Int {
        val r = (Color.red(x) * (1 - f) + Color.red(y) * f).toInt()
        val g = (Color.green(x) * (1 - f) + Color.green(y) * f).toInt()
        val b = (Color.blue(x) * (1 - f) + Color.blue(y) * f).toInt()
        return Color.rgb(r, g, b)
    }
}

object Guard {
    private var fails = 0
    private var until = 0L

    fun wait(): Long {
        val l = until - System.currentTimeMillis()
        return if (l > 0) (l + 999) / 1000 else 0L
    }

    fun fail() {
        fails++
        if (fails >= 5) {
            until = System.currentTimeMillis() + 30000
            fails = 0
        }
    }

    fun ok() {
        fails = 0
        until = 0L
    }
}

object Ui {
    val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, n: Int) = (n * c.resources.displayMetrics.density).toInt()

    fun rect(color: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = r
        return g
    }

    fun oval(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        return g
    }

    fun grad(a: Int, b: Int, r: Float): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b))
        g.cornerRadius = r
        return g
    }

    fun bg(c: Context): GradientDrawable {
        val t = Palette.cur(c)
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Palette.blend(Palette.BG, t.b, 0.4f), Palette.BG)
        )
    }

    fun tv(c: Context, s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    fun card(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = rect(Palette.CARD, dp(c, 20).toFloat())
        l.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18))
        return l
    }

    fun primary(c: Context, text: String, onClick: () -> Unit): Button {
        val t = Palette.cur(c)
        val b = Button(c)
        b.text = text
        b.setAllCaps(false)
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.typeface = Typeface.DEFAULT_BOLD
        b.background = grad(t.a, t.b, dp(c, 14).toFloat())
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    fun outline(c: Context, text: String, onClick: () -> Unit): Button {
        val t = Palette.cur(c)
        val g = GradientDrawable()
        g.setColor(Color.TRANSPARENT)
        g.cornerRadius = dp(c, 14).toFloat()
        g.setStroke(dp(c, 2), t.a)
        val b = Button(c)
        b.text = text
        b.setAllCaps(false)
        b.textSize = 16f
        b.setTextColor(Palette.SOFT)
        b.typeface = Typeface.DEFAULT_BOLD
        b.background = g
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    fun buzz(c: Context) {
        try {
            val v = c.getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
    }

    fun hasFinger(c: Context) = c.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
    fun fingerOk(c: Context) = Store.finger(c) && hasFinger(c)

    fun verify(c: Context, pad: PinPad, p: String): Boolean {
        val w = Guard.wait()
        if (w > 0) {
            Toast.makeText(c, "Too many attempts. Try again in " + w + "s", Toast.LENGTH_SHORT).show()
            pad.wrong()
            return false
        }
        if (Store.checkPin(c, p)) {
            Guard.ok()
            return true
        }
        Guard.fail()
        pad.wrong()
        return false
    }

    fun finger(a: Activity, title: String, ok: () -> Unit): CancellationSignal? {
        if (!fingerOk(a)) return null
        return try {
            val ex = a.mainExecutor
            val bp = BiometricPrompt.Builder(a)
                .setTitle(title)
                .setNegativeButton("Use PIN", ex) { _, _ -> }
                .build()
            val cs = CancellationSignal()
            bp.authenticate(cs, ex, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) {
                    ok()
                }
            })
            cs
        } catch (e: Exception) {
            null
        }
    }
}

class IconView(c: Context, private val kind: String, private val color: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height) / 24f
        cv.save()
        cv.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        cv.scale(s, s)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            "lock" -> {
                cv.drawRoundRect(5f, 11f, 19f, 20f, 2f, 2f, p)
                val a = Path()
                a.moveTo(8f, 11f)
                a.lineTo(8f, 8f)
                a.arcTo(RectF(8f, 4f, 16f, 12f), 180f, 180f)
                a.lineTo(16f, 11f)
                cv.drawPath(a, p)
            }
            "shield" -> {
                val a = Path()
                a.moveTo(12f, 3f)
                a.lineTo(19f, 6f)
                a.lineTo(19f, 11f)
                a.quadTo(19f, 17f, 12f, 21f)
                a.quadTo(5f, 17f, 5f, 11f)
                a.lineTo(5f, 6f)
                a.close()
                cv.drawPath(a, p)
                val k = Path()
                k.moveTo(9f, 12f)
                k.lineTo(11f, 14f)
                k.lineTo(15f, 10f)
                cv.drawPath(k, p)
            }
            "check" -> {
                val a = Path()
                a.moveTo(5f, 12.5f)
                a.lineTo(10f, 17f)
                a.lineTo(19f, 7f)
                cv.drawPath(a, p)
            }
            "back" -> {
                val a = Path()
                a.moveTo(15f, 5f)
                a.lineTo(8f, 12f)
                a.lineTo(15f, 19f)
                cv.drawPath(a, p)
            }
            "chev" -> {
                val a = Path()
                a.moveTo(9f, 5f)
                a.lineTo(16f, 12f)
                a.lineTo(9f, 19f)
                cv.drawPath(a, p)
            }
            "backspace" -> {
                val a = Path()
                a.moveTo(9f, 5f)
                a.lineTo(21f, 5f)
                a.lineTo(21f, 19f)
                a.lineTo(9f, 19f)
                a.lineTo(3f, 12f)
                a.close()
                cv.drawPath(a, p)
                cv.drawLine(12f, 9.5f, 17f, 14.5f, p)
                cv.drawLine(17f, 9.5f, 12f, 14.5f, p)
            }
            "finger" -> {
                cv.drawArc(RectF(3f, 3f, 21f, 21f), 200f, 140f, false, p)
                cv.drawArc(RectF(6f, 6f, 18f, 18f), 190f, 160f, false, p)
                cv.drawArc(RectF(9f, 9f, 15f, 15f), 180f, 180f, false, p)
                cv.drawLine(12f, 12f, 12f, 20f, p)
                cv.drawLine(8f, 13f, 8f, 19f, p)
                cv.drawLine(16f, 13f, 16f, 17f, p)
            }
            "apps" -> {
                cv.drawRoundRect(4f, 4f, 11f, 11f, 2f, 2f, p)
                cv.drawRoundRect(13f, 4f, 20f, 11f, 2f, 2f, p)
                cv.drawRoundRect(4f, 13f, 11f, 20f, 2f, 2f, p)
                cv.drawRoundRect(13f, 13f, 20f, 20f, 2f, 2f, p)
            }
            "palette" -> {
                cv.drawCircle(12f, 12f, 8f, p)
                p.style = Paint.Style.FILL
                cv.drawCircle(8f, 10f, 1.3f, p)
                cv.drawCircle(12f, 7.5f, 1.3f, p)
                cv.drawCircle(16f, 10f, 1.3f, p)
            }
            "gear" -> {
                cv.drawLine(4f, 7f, 13f, 7f, p)
                cv.drawLine(19f, 7f, 20f, 7f, p)
                cv.drawLine(4f, 17f, 5f, 17f, p)
                cv.drawLine(11f, 17f, 20f, 17f, p)
                cv.drawCircle(16f, 7f, 2.5f, p)
                cv.drawCircle(8f, 17f, 2.5f, p)
            }
        }
        cv.restore()
    }
}

class Toggle(
    c: Context,
    on0: Boolean,
    private val light: Boolean = false,
    private val onChange: (Boolean) -> Unit
) : View(c) {
    var on = on0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        setOnClickListener {
            on = !on
            invalidate()
            onChange(on)
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val acc = Palette.cur(context).a
        p.style = Paint.Style.FILL
        p.color = if (light) Color.WHITE else if (on) acc else 0xFF3A3F6B.toInt()
        cv.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        p.color = if (light) (if (on) acc else 0xFF9AA0C8.toInt()) else Color.WHITE
        val cx = if (on) w - h / 2f else h / 2f
        cv.drawCircle(cx, h / 2f, h * 0.36f, p)
    }
}

class PinPad(
    c: Context,
    showFinger: Boolean,
    private val onFinger: () -> Unit,
    private val onDone: (String) -> Unit
) : LinearLayout(c) {
    private val sb = StringBuilder()
    private val dots = ArrayList<View>()

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        val row0 = LinearLayout(c)
        for (i in 0 until 4) {
            val v = View(c)
            dots.add(v)
            val l = LinearLayout.LayoutParams(Ui.dp(c, 14), Ui.dp(c, 14))
            l.setMargins(Ui.dp(c, 9), 0, Ui.dp(c, 9), 0)
            row0.addView(v, l)
        }
        val l0 = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        l0.topMargin = Ui.dp(c, 28)
        l0.bottomMargin = Ui.dp(c, 32)
        addView(row0, l0)
        refresh()
        val rows = arrayOf(
            arrayOf("1", "2", "3"),
            arrayOf("4", "5", "6"),
            arrayOf("7", "8", "9"),
            arrayOf(if (showFinger) "F" else "", "0", "D")
        )
        for (r in rows) {
            val line = LinearLayout(c)
            for (k in r) {
                val l = LinearLayout.LayoutParams(Ui.dp(c, 72), Ui.dp(c, 72))
                l.setMargins(Ui.dp(c, 14), 0, Ui.dp(c, 14), 0)
                line.addView(key(c, k), l)
            }
            val ll = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
            ll.bottomMargin = Ui.dp(c, 16)
            addView(line, ll)
        }
    }

    private fun key(c: Context, k: String): View {
        if (k == "") return View(c)
        val f = FrameLayout(c)
        val special = k == "F" || k == "D"
        val shape = if (special) null else Ui.oval(Palette.CARD)
        f.background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape, Ui.oval(Color.WHITE))
        if (special) {
            val ic = IconView(c, if (k == "F") "finger" else "backspace", if (k == "F") Palette.SOFT else Palette.MUTED)
            f.addView(ic, FrameLayout.LayoutParams(Ui.dp(c, 30), Ui.dp(c, 30), Gravity.CENTER))
            f.contentDescription = if (k == "F") "Use fingerprint" else "Delete"
        } else {
            val t = Ui.tv(c, k, 28f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            f.addView(t, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        }
        f.setOnClickListener { press(k) }
        return f
    }

    private fun press(k: String) {
        if (k == "F") {
            onFinger()
        } else if (k == "D") {
            if (sb.isNotEmpty()) {
                sb.setLength(sb.length - 1)
                refresh()
            }
        } else if (sb.length < 4) {
            sb.append(k)
            refresh()
            if (sb.length == 4) postDelayed({ onDone(sb.toString()) }, 120)
        }
    }

    private fun refresh() {
        val acc = Palette.cur(context).a
        for (i in dots.indices) {
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            if (i < sb.length) {
                d.setColor(acc)
            } else {
                d.setColor(Color.TRANSPARENT)
                d.setStroke(Ui.dp(context, 2), 0xFF4A4F7A.toInt())
            }
            dots[i].background = d
        }
    }

    fun reset() {
        sb.setLength(0)
        refresh()
    }

    fun wrong() {
        Ui.buzz(context)
        ObjectAnimator.ofFloat(this, "translationX", 0f, -28f, 28f, -18f, 18f, -8f, 8f, 0f)
            .setDuration(380).start()
        postDelayed({ reset() }, 260)
    }
}
