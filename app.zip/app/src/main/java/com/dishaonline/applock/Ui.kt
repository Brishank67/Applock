package com.dishaonline.applock

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object Palette {
    val BG = 0xFF060A1E.toInt()
    val BG_TOP = 0xFF0B1A4A.toInt()
    val CARD = 0xFF0D1330.toInt()
    val BORDER = 0xFF1B2E6B.toInt()
    val LINE = 0xFF1A2552.toInt()
    val MUTED = 0xFF8FA0D8.toInt()
    val CYAN = 0xFF00C2FF.toInt()
    val BLUE = 0xFF2D7BFF.toInt()
    val PURPLE = 0xFF7C4DFF.toInt()
    val GREEN = 0xFF1FA971.toInt()
    val KEY = 0xFF0A1236.toInt()
    val KEYRING = 0xFF1F5FD6.toInt()
}

object Guard {
    private var fails = 0
    private var until = 0L

    fun wait(): Long {
        val l = until - System.currentTimeMillis()
        return if (l > 0) (l + 999) / 1000 else 0L
    }

    fun fail() {
        fails++
        if (fails >= 5) {
            until = System.currentTimeMillis() + 30000
            fails = 0
        }
    }

    fun ok() {
        fails = 0
        until = 0L
    }
}

object Ui {
    val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, n: Int) = (n * c.resources.displayMetrics.density).toInt()

    fun rect(c: Context, color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, r).toFloat()
        if (stroke != 0) g.setStroke(dp(c, 1), stroke)
        return g
    }

    fun oval(color: Int, stroke: Int = 0, sw: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        if (stroke != 0) g.setStroke(sw, stroke)
        return g
    }

    fun pill(c: Context): GradientDrawable {
        val g = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Palette.CYAN, Palette.BLUE, Palette.PURPLE)
        )
        g.cornerRadius = dp(c, 26).toFloat()
        return g
    }

    fun bg(): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Palette.BG_TOP, Palette.BG))

    fun tv(c: Context, s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    fun brand(c: Context, size: Float): TextView {
        val s = SpannableString("AruShield")
        s.setSpan(ForegroundColorSpan(Color.WHITE), 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(ForegroundColorSpan(Palette.CYAN), 3, 9, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        val t = TextView(c)
        t.text = s
        t.textSize = size
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.textAlignment = View.TEXT_ALIGNMENT_CENTER
        t.includeFontPadding = false
        return t
    }

    fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    fun card(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = rect(c, Palette.CARD, 18, Palette.BORDER)
        l.setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16))
        return l
    }

    fun primary(c: Context, text: String, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = text
        b.setAllCaps(false)
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.typeface = Typeface.DEFAULT_BOLD
        b.background = pill(c)
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    fun outline(c: Context, text: String, onClick: () -> Unit): Button {
        val g = GradientDrawable()
        g.setColor(Color.TRANSPARENT)
        g.cornerRadius = dp(c, 26).toFloat()
        g.setStroke(dp(c, 2), Palette.BLUE)
        val b = Button(c)
        b.text = text
        b.setAllCaps(false)
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.typeface = Typeface.DEFAULT_BOLD
        b.background = g
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    fun buzz(c: Context) {
        try {
            val v = c.getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
    }

    fun hasFinger(c: Context) = c.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
    fun fingerOk(c: Context) = Store.finger(c) && hasFinger(c)

    fun fingerRow(c: Context, onClick: () -> Unit): View {
        val r = LinearLayout(c)
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(IconView(c, "finger", Palette.CYAN), lp(dp(c, 28), dp(c, 28)))
        val t = tv(c, "Use Fingerprint", 15f, Color.WHITE)
        t.setPadding(dp(c, 10), 0, 0, 0)
        r.addView(t)
        r.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
        r.setOnClickListener { onClick() }
        return r
    }

    fun brandHeader(c: Context, logo: Int, size: Float): View {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER_HORIZONTAL
        l.addView(LogoView(c), lp(dp(c, logo), dp(c, logo)))
        val name = brand(c, size)
        val nameLp = lp(MATCH, WRAP)
        nameLp.topMargin = dp(c, 8)
        l.addView(name, nameLp)
        return l
    }

    fun verify(c: Context, pad: PinPad, p: String): Boolean {
        val w = Guard.wait()
        if (w > 0) {
            Toast.makeText(c, "Too many attempts. Try again in " + w + "s", Toast.LENGTH_SHORT).show()
            pad.wrong()
            return false
        }
        if (Store.checkPin(c, p)) {
            Guard.ok()
            return true
        }
        Guard.fail()
        pad.wrong()
        return false
    }

    fun finger(a: Activity, title: String, ok: () -> Unit): CancellationSignal? {
        if (!fingerOk(a)) return null
        return try {
            val ex = a.mainExecutor
            val bp = BiometricPrompt.Builder(a)
                .setTitle(title)
                .setNegativeButton("Use PIN", ex) { _, _ -> }
                .build()
            val cs = CancellationSignal()
            bp.authenticate(cs, ex, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) {
                    ok()
                }
            })
            cs
        } catch (e: Exception) {
            null
        }
    }
}

class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height) / 100f
        cv.save()
        cv.translate((width - 100f * s) / 2f, (height - 100f * s) / 2f)
        cv.scale(s, s)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.6f
        p.shader = LinearGradient(0f, 0f, 100f, 0f, Palette.CYAN, Palette.PURPLE, Shader.TileMode.CLAMP)
        cv.save()
        cv.rotate(-18f, 50f, 56f)
        cv.drawOval(RectF(1f, 40f, 99f, 72f), p)
        cv.restore()
        val sh = Path()
        sh.moveTo(50f, 6f)
        sh.lineTo(86f, 20f)
        sh.lineTo(86f, 50f)
        sh.quadTo(86f, 78f, 50f, 94f)
        sh.quadTo(14f, 78f, 14f, 50f)
        sh.lineTo(14f, 20f)
        sh.close()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            14f, 6f, 86f, 94f,
            intArrayOf(Palette.CYAN, Palette.BLUE, Palette.PURPLE), null, Shader.TileMode.CLAMP
        )
        cv.drawPath(sh, p)
        p.shader = null
        p.color = 0xFF0B1B52.toInt()
        cv.save()
        cv.scale(0.82f, 0.82f, 50f, 52f)
        cv.drawPath(sh, p)
        cv.restore()
        p.color = Color.WHITE
        cv.drawRoundRect(37f, 46f, 63f, 70f, 4f, 4f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        val sk = Path()
        sk.moveTo(42f, 46f)
        sk.lineTo(42f, 40f)
        sk.arcTo(RectF(42f, 31f, 58f, 47f), 180f, 180f)
        sk.lineTo(58f, 46f)
        cv.drawPath(sk, p)
        p.style = Paint.Style.FILL
        p.color = 0xFF0B1B52.toInt()
        cv.drawCircle(50f, 57f, 3.2f, p)
        cv.drawRect(48.9f, 57f, 51.1f, 64f, p)
        cv.restore()
    }
}

class RingView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 12f * d
        p.style = Paint.Style.FILL
        p.color = 0xFF08102C.toInt()
        cv.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 16f * d
        p.color = 0x221E6BFF
        cv.drawCircle(cx, cy, r, p)
        p.strokeWidth = 6f * d
        p.shader = SweepGradient(
            cx, cy, intArrayOf(Palette.CYAN, Palette.BLUE, Palette.PURPLE, Palette.CYAN), null
        )
        cv.drawCircle(cx, cy, r, p)
        p.shader = null
    }
}

class BarView(c: Context) : View(c) {
    var frac = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = Palette.LINE
        cv.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        p.shader = LinearGradient(0f, 0f, w, 0f, Palette.CYAN, Palette.PURPLE, Shader.TileMode.CLAMP)
        cv.drawRoundRect(0f, 0f, w * frac, h, h / 2f, h / 2f, p)
        p.shader = null
    }
}

class IconView(c: Context, private val kind: String, private val color: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height) / 24f
        cv.save()
        cv.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        cv.scale(s, s)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        val a = Path()
        when (kind) {
            "lock" -> {
                cv.drawRoundRect(5f, 11f, 19f, 20f, 2f, 2f, p)
                a.moveTo(8f, 11f)
                a.lineTo(8f, 8f)
                a.arcTo(RectF(8f, 4f, 16f, 12f), 180f, 180f)
                a.lineTo(16f, 11f)
                cv.drawPath(a, p)
            }
            "shield" -> {
                a.moveTo(12f, 3f)
                a.lineTo(19f, 6f)
                a.lineTo(19f, 11f)
                a.quadTo(19f, 17f, 12f, 21f)
                a.quadTo(5f, 17f, 5f, 11f)
                a.lineTo(5f, 6f)
                a.close()
                cv.drawPath(a, p)
                val k = Path()
                k.moveTo(9f, 12f)
                k.lineTo(11f, 14f)
                k.lineTo(15f, 10f)
                cv.drawPath(k, p)
            }
            "check" -> {
                a.moveTo(5f, 12.5f)
                a.lineTo(10f, 17f)
                a.lineTo(19f, 7f)
                cv.drawPath(a, p)
            }
            "back" -> {
                a.moveTo(15f, 5f)
                a.lineTo(8f, 12f)
                a.lineTo(15f, 19f)
                cv.drawPath(a, p)
            }
            "chev" -> {
                a.moveTo(9f, 5f)
                a.lineTo(16f, 12f)
                a.lineTo(9f, 19f)
                cv.drawPath(a, p)
            }
            "backspace" -> {
                a.moveTo(9f, 5f)
                a.lineTo(21f, 5f)
                a.lineTo(21f, 19f)
                a.lineTo(9f, 19f)
                a.lineTo(3f, 12f)
                a.close()
                cv.drawPath(a, p)
                cv.drawLine(12f, 9.5f, 17f, 14.5f, p)
                cv.drawLine(17f, 9.5f, 12f, 14.5f, p)
            }
            "finger" -> {
                cv.drawArc(RectF(3f, 3f, 21f, 21f), 200f, 140f, false, p)
                cv.drawArc(RectF(6f, 6f, 18f, 18f), 190f, 160f, false, p)
                cv.drawArc(RectF(9f, 9f, 15f, 15f), 180f, 180f, false, p)
                cv.drawLine(12f, 12f, 12f, 20f, p)
                cv.drawLine(8f, 13f, 8f, 19f, p)
                cv.drawLine(16f, 13f, 16f, 17f, p)
            }
            "apps" -> {
                cv.drawRoundRect(4f, 4f, 11f, 11f, 2f, 2f, p)
                cv.drawRoundRect(13f, 4f, 20f, 11f, 2f, 2f, p)
                cv.drawRoundRect(4f, 13f, 11f, 20f, 2f, 2f, p)
                cv.drawRoundRect(13f, 13f, 20f, 20f, 2f, 2f, p)
            }
            "gear" -> {
                cv.drawLine(4f, 7f, 13f, 7f, p)
                cv.drawLine(19f, 7f, 20f, 7f, p)
                cv.drawLine(4f, 17f, 5f, 17f, p)
                cv.drawLine(11f, 17f, 20f, 17f, p)
                cv.drawCircle(16f, 7f, 2.5f, p)
                cv.drawCircle(8f, 17f, 2.5f, p)
            }
            "home" -> {
                a.moveTo(4f, 11f)
                a.lineTo(12f, 4f)
                a.lineTo(20f, 11f)
                cv.drawPath(a, p)
                val b = Path()
                b.moveTo(6f, 10f)
                b.lineTo(6f, 20f)
                b.lineTo(18f, 20f)
                b.lineTo(18f, 10f)
                cv.drawPath(b, p)
            }
            "clock" -> {
                cv.drawCircle(12f, 12f, 8f, p)
                a.moveTo(12f, 7f)
                a.lineTo(12f, 12f)
                a.lineTo(15f, 14f)
                cv.drawPath(a, p)
            }
            "bell" -> {
                cv.drawArc(RectF(7f, 5f, 17f, 15f), 180f, 180f, false, p)
                cv.drawLine(7f, 10f, 7f, 16f, p)
                cv.drawLine(17f, 10f, 17f, 16f, p)
                cv.drawLine(5f, 17f, 19f, 17f, p)
                cv.drawArc(RectF(10f, 17f, 14f, 21f), 0f, 180f, false, p)
            }
            "info" -> {
                cv.drawCircle(12f, 12f, 9f, p)
                cv.drawLine(12f, 11f, 12f, 16f, p)
                cv.drawLine(12f, 8f, 12f, 8.2f, p)
            }
            "doc" -> {
                cv.drawRoundRect(6f, 3f, 18f, 21f, 2f, 2f, p)
                cv.drawLine(9f, 9f, 15f, 9f, p)
                cv.drawLine(9f, 13f, 15f, 13f, p)
                cv.drawLine(9f, 17f, 13f, 17f, p)
            }
            "eye" -> {
                cv.drawOval(RectF(3f, 7f, 21f, 17f), p)
                cv.drawCircle(12f, 12f, 2.5f, p)
            }
            "bolt" -> {
                a.moveTo(13f, 3f)
                a.lineTo(6f, 13f)
                a.lineTo(12f, 13f)
                a.lineTo(11f, 21f)
                a.lineTo(18f, 10f)
                a.lineTo(12f, 10f)
                a.close()
                cv.drawPath(a, p)
            }
            "plus" -> {
                cv.drawLine(12f, 5f, 12f, 19f, p)
                cv.drawLine(5f, 12f, 19f, 12f, p)
            }
        }
        cv.restore()
    }
}

class Toggle(
    c: Context,
    on0: Boolean,
    private val onChange: (Boolean) -> Unit
) : View(c) {
    var on = on0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        setOnClickListener {
            on = !on
            invalidate()
            onChange(on)
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = if (on) Palette.BLUE else 0xFF2A3150.toInt()
        cv.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        p.color = Color.WHITE
        val cx = if (on) w - h / 2f else h / 2f
        cv.drawCircle(cx, h / 2f, h * 0.36f, p)
    }
}

class PinPad(
    c: Context,
    private val onDone: (String) -> Unit
) : LinearLayout(c) {
    companion object { const val LEN = 6 }

    private val sb = StringBuilder()
    private val dots = ArrayList<View>()

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        val row0 = LinearLayout(c)
        for (i in 0 until LEN) {
            val v = View(c)
            dots.add(v)
            val l = LinearLayout.LayoutParams(Ui.dp(c, 14), Ui.dp(c, 14))
            l.setMargins(Ui.dp(c, 7), 0, Ui.dp(c, 7), 0)
            row0.addView(v, l)
        }
        val l0 = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        l0.topMargin = Ui.dp(c, 24)
        l0.bottomMargin = Ui.dp(c, 28)
        addView(row0, l0)
        refresh()
        val rows = arrayOf(
            arrayOf("1", "2", "3"),
            arrayOf("4", "5", "6"),
            arrayOf("7", "8", "9"),
            arrayOf("", "0", "D")
        )
        for (r in rows) {
            val line = LinearLayout(c)
            for (k in r) {
                val l = LinearLayout.LayoutParams(Ui.dp(c, 66), Ui.dp(c, 66))
                l.setMargins(Ui.dp(c, 11), 0, Ui.dp(c, 11), 0)
                line.addView(key(c, k), l)
            }
            val ll = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
            ll.bottomMargin = Ui.dp(c, 14)
            addView(line, ll)
        }
    }

    private fun key(c: Context, k: String): View {
        if (k == "") return View(c)
        val f = FrameLayout(c)
        val del = k == "D"
        val shape = if (del) null else Ui.oval(Palette.KEY, Palette.KEYRING, Ui.dp(c, 2))
        f.background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape, Ui.oval(Color.WHITE))
        if (del) {
            f.addView(IconView(c, "backspace", Palette.CYAN), FrameLayout.LayoutParams(Ui.dp(c, 28), Ui.dp(c, 28), Gravity.CENTER))
            f.contentDescription = "Delete"
        } else {
            val t = Ui.tv(c, k, 24f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            f.addView(t, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        }
        f.setOnClickListener { press(k) }
        return f
    }

    private fun press(k: String) {
        if (k == "D") {
            if (sb.isNotEmpty()) {
                sb.setLength(sb.length - 1)
                refresh()
            }
        } else if (sb.length < LEN) {
            sb.append(k)
            refresh()
            if (sb.length == LEN) postDelayed({ onDone(sb.toString()) }, 120)
        }
    }

    private fun refresh() {
        for (i in dots.indices) {
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            if (i < sb.length) {
                d.setColor(Palette.CYAN)
            } else {
                d.setColor(Color.TRANSPARENT)
                d.setStroke(Ui.dp(context, 2), Palette.BLUE)
            }
            dots[i].background = d
        }
    }

    fun reset() {
        sb.setLength(0)
        refresh()
    }

    fun wrong() {
        Ui.buzz(context)
        ObjectAnimator.ofFloat(this, "translationX", 0f, -28f, 28f, -18f, 18f, -8f, 8f, 0f)
            .setDuration(380).start()
        postDelayed({ reset() }, 260)
    }
}
