package com.dishaonline.applock

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        var unlocked = false
        var detour = false
        var splashDone = false
        var introDone = false
    }

    private lateinit var host: FrameLayout
    private var tab = 0
    private var back: (() -> Unit)? = null
    private var cancel: CancellationSignal? = null

    private val questions = arrayOf(
        "What is your pet's name?",
        "What was your first school's name?",
        "In which city were you born?",
        "What is your favourite teacher's name?"
    )

    private fun dp(n: Int) = Ui.dp(this, n)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = Palette.BG_TOP
        window.navigationBarColor = Palette.BG
        host = FrameLayout(this)
        host.setBackgroundColor(Palette.BG)
        setContentView(host)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        if (!splashDone) {
            showSplash()
            host.postDelayed({
                splashDone = true
                route()
            }, 1300)
        }
    }

    override fun onResume() {
        super.onResume()
        if (splashDone) route()
    }

    override fun onStop() {
        super.onStop()
        if (detour) detour = false else unlocked = false
    }

    override fun onDestroy() {
        cancel?.cancel()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = back
        if (b != null) b() else finish()
    }

    // ---------- routing and helpers ----------

    private fun hasUsage(): Boolean {
        val a = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return a.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun route() {
        cancel?.cancel()
        cancel = null
        if (!Store.hasPin(this)) {
            if (!introDone) showIntro(0) else createFlow()
        } else if (!unlocked) {
            showGate()
        } else if (!(hasUsage() && Settings.canDrawOverlays(this)) || !Store.onboarded(this)) {
            showPerms()
        } else {
            showMain(tab)
        }
    }

    private fun setScreen(v: View) {
        back = null
        host.removeAllViews()
        host.addView(v, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun scroll(v: View): View {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(v, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        return sv
    }

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(24), dp(48), dp(24), dp(24))
        c.background = Ui.bg()
        return c
    }

    private fun stepView(s: String): TextView {
        val t = Ui.tv(this, s, 13f, Palette.MUTED)
        t.letterSpacing = 0.08f
        return t
    }

    private fun linkBtn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setAllCaps(false)
        b.setTextColor(Palette.CYAN)
        b.background = null
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(Palette.MUTED)
        e.setTextColor(Color.WHITE)
        e.textSize = 16f
        e.setPadding(dp(16), 0, dp(16), 0)
        e.background = Ui.rect(this, Palette.CARD, 14, Palette.BORDER)
        e.inputType = InputType.TYPE_CLASS_TEXT
        e.isSingleLine = true
        return e
    }

    private fun circleBtn(icon: String, desc: String, onClick: () -> Unit): View {
        val f = FrameLayout(this)
        f.background = Ui.oval(Palette.CARD, Palette.BORDER, dp(1))
        f.addView(IconView(this, icon, Color.WHITE), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        f.contentDescription = desc
        f.setOnClickListener { onClick() }
        return f
    }

    // ---------- splash and intro ----------

    private fun showSplash() {
        val root = FrameLayout(this)
        root.background = Ui.bg()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.addView(LogoView(this), Ui.lp(dp(150), dp(150)))
        val nm = Ui.brand(this, 40f)
        val nl = Ui.lp(Ui.MATCH, Ui.WRAP)
        nl.topMargin = dp(10)
        col.addView(nm, nl)
        val tg = Ui.tv(this, "Your Apps  \u2022  Our Protection", 13f, Palette.MUTED)
        val tl = Ui.lp(Ui.WRAP, Ui.WRAP)
        tl.topMargin = dp(8)
        col.addView(tg, tl)
        root.addView(col, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        val bar = BarView(this)
        val bl = FrameLayout.LayoutParams(dp(120), dp(4), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        bl.bottomMargin = dp(64)
        root.addView(bar, bl)
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 1200
        anim.addUpdateListener {
            bar.frac = it.animatedValue as Float
            bar.invalidate()
        }
        anim.start()
        setScreen(root)
    }

    private fun tile(color: Int, icon: String): View {
        val f = FrameLayout(this)
        f.background = Ui.rect(this, color, 14)
        f.addView(IconView(this, icon, Color.WHITE), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        return f
    }

    private fun fl(w: Int, h: Int, g: Int, l: Int, t: Int): FrameLayout.LayoutParams {
        val p = FrameLayout.LayoutParams(dp(w), dp(h), g)
        p.leftMargin = dp(l)
        p.topMargin = dp(t)
        return p
    }

    private fun illus(i: Int): View {
        val f = FrameLayout(this)
        if (i == 0) {
            f.addView(LogoView(this), fl(130, 130, Gravity.CENTER, 0, 0))
            f.addView(tile(0xFF1FA971.toInt(), "lock"), fl(46, 46, Gravity.TOP or Gravity.START, 10, 6))
            f.addView(tile(0xFFC0267A.toInt(), "eye"), fl(46, 46, Gravity.TOP or Gravity.END, 0, 0))
            f.addView(tile(0xFF7C4DFF.toInt(), "apps"), fl(46, 46, Gravity.BOTTOM or Gravity.START, 0, 0))
            f.addView(tile(0xFF2D7BFF.toInt(), "check"), fl(46, 46, Gravity.BOTTOM or Gravity.END, 0, 0))
        } else if (i == 1) {
            val cd = Ui.card(this)
            for (r in 0 until 3) {
                val row = LinearLayout(this)
                row.gravity = Gravity.CENTER_VERTICAL
                val sq = View(this)
                sq.background = Ui.rect(this, if (r == 0) Palette.BLUE else Palette.LINE, 8)
                row.addView(sq, Ui.lp(dp(30), dp(30)))
                val bars = LinearLayout(this)
                bars.orientation = LinearLayout.VERTICAL
                val b1 = View(this)
                b1.background = Ui.rect(this, Palette.BORDER, 3)
                val b2 = View(this)
                b2.background = Ui.rect(this, Palette.LINE, 3)
                bars.addView(b1, Ui.lp(dp(90), dp(6)))
                val b2l = Ui.lp(dp(60), dp(6))
                b2l.topMargin = dp(6)
                bars.addView(b2, b2l)
                val bl = Ui.lp(Ui.WRAP, Ui.WRAP)
                bl.leftMargin = dp(12)
                row.addView(bars, bl)
                val rl = Ui.lp(Ui.WRAP, Ui.WRAP)
                rl.topMargin = dp(if (r == 0) 0 else 16)
                cd.addView(row, rl)
            }
            f.addView(cd, fl(180, 170, Gravity.CENTER, 0, 0))
            val badge = FrameLayout(this)
            badge.background = Ui.pill(this).also { it.cornerRadius = dp(26).toFloat() }
            badge.addView(IconView(this, "lock", Color.WHITE), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            f.addView(badge, fl(52, 52, Gravity.BOTTOM or Gravity.END, 0, 0))
        } else {
            f.addView(LogoView(this), fl(160, 160, Gravity.CENTER, 0, 0))
            val badge = FrameLayout(this)
            badge.background = Ui.oval(Palette.KEY, Palette.CYAN, dp(2))
            badge.addView(IconView(this, "finger", Palette.CYAN), FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
            f.addView(badge, fl(66, 66, Gravity.BOTTOM or Gravity.END, 0, 0))
        }
        return f
    }

    private val introTitles = arrayOf("Welcome to\nAruShield", "Choose Apps\nto Protect", "Set Your Lock")
    private val introSubs = arrayOf(
        "Lock your apps, protect your privacy and keep your data safe.",
        "Select the apps you want to lock and keep your personal data safe.",
        "Create a PIN or use fingerprint to secure your apps."
    )

    private fun showIntro(i: Int) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(24), dp(40), dp(24), dp(28))
        root.background = Ui.bg()

        val top = FrameLayout(this)
        if (i > 0) {
            top.addView(circleBtn("back", "Back") { showIntro(i - 1) }, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.START))
        }
        val skip = linkBtn("Skip") {
            introDone = true
            route()
        }
        skip.setTextColor(Palette.MUTED)
        top.addView(skip, FrameLayout.LayoutParams(Ui.WRAP, dp(40), Gravity.END))
        root.addView(top, Ui.lp(Ui.MATCH, dp(44)))

        val il = LinearLayout.LayoutParams(Ui.MATCH, 0, 1f)
        root.addView(illus(i), il)

        val t = Ui.tv(this, introTitles[i], 28f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        root.addView(t, Ui.lp(Ui.WRAP, Ui.WRAP))
        val s = Ui.tv(this, introSubs[i], 15f, Palette.MUTED)
        s.gravity = Gravity.CENTER
        val sl = Ui.lp(Ui.MATCH, Ui.WRAP)
        sl.topMargin = dp(12)
        root.addView(s, sl)

        val btn = Ui.primary(this, if (i < 2) "Next  \u2192" else "Get Started") {
            if (i < 2) {
                showIntro(i + 1)
            } else {
                introDone = true
                route()
            }
        }
        val bl = Ui.lp(Ui.MATCH, dp(52))
        bl.topMargin = dp(28)
        root.addView(btn, bl)

        val dots = LinearLayout(this)
        for (k in 0 until 3) {
            val d = View(this)
            d.background = Ui.oval(if (k == i) Palette.CYAN else Palette.LINE)
            val dl = Ui.lp(dp(8), dp(8))
            dl.leftMargin = dp(5)
            dl.rightMargin = dp(5)
            dots.addView(d, dl)
        }
        val ddl = Ui.lp(Ui.WRAP, Ui.WRAP)
        ddl.topMargin = dp(20)
        root.addView(dots, ddl)
        setScreen(root)
        if (i > 0) back = { showIntro(i - 1) }
    }

    // ---------- PIN screens ----------

    private fun pinScreen(
        top: View?, title: String, sub: String, footer: View?,
        onDone: (PinPad, String) -> Unit
    ) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(24), dp(44), dp(24), dp(20))
        root.background = Ui.bg()
        if (top != null) root.addView(top)
        val t1 = Ui.tv(this, title, 22f, Color.WHITE, true)
        t1.gravity = Gravity.CENTER
        val l1 = Ui.lp(Ui.WRAP, Ui.WRAP)
        l1.topMargin = dp(22)
        root.addView(t1, l1)
        val t2 = Ui.tv(this, sub, 14f, Palette.MUTED)
        t2.gravity = Gravity.CENTER
        val l2 = Ui.lp(Ui.WRAP, Ui.WRAP)
        l2.topMargin = dp(6)
        root.addView(t2, l2)
        var pad: PinPad? = null
        pad = PinPad(this) { p -> onDone(pad!!, p) }
        root.addView(pad)
        if (footer != null) root.addView(footer)
        setScreen(scroll(root))
    }

    private fun askFinger() {
        cancel?.cancel()
        cancel = Ui.finger(this, "Unlock AruShield") {
            unlocked = true
            route()
        }
    }

    private fun showGate() {
        val fin = Ui.fingerOk(this)
        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.VERTICAL
        foot.gravity = Gravity.CENTER_HORIZONTAL
        if (fin) foot.addView(Ui.fingerRow(this) { askFinger() })
        foot.addView(linkBtn("Forgot PIN?") { showForgot() }, Ui.lp(Ui.WRAP, dp(44)))
        pinScreen(Ui.brandHeader(this, 64, 28f), "App Locked", "Enter your PIN to continue", foot) { pad, p ->
            if (Ui.verify(this, pad, p)) {
                unlocked = true
                route()
            }
        }
        if (fin) host.post { askFinger() }
    }

    private fun pinTwice(
        step: String?, t1: String, s1: String, onBack: (() -> Unit)?, onSet: (String) -> Unit
    ) {
        pinScreen(if (step == null) null else stepView(step), t1, s1, null) { _, first ->
            pinScreen(
                if (step == null) null else stepView(step),
                "Confirm your PIN", "Enter the same PIN again.", null
            ) { pad2, second ->
                if (second == first) {
                    onSet(first)
                } else {
                    pad2.wrong()
                    toast("PINs do not match")
                    host.postDelayed({ pinTwice(step, t1, s1, onBack, onSet) }, 600)
                }
            }
            back = { pinTwice(step, t1, s1, onBack, onSet) }
        }
        back = onBack
    }

    private fun createFlow() {
        pinTwice(
            "STEP 1 OF 3", "Create your PIN",
            "Choose a 6-digit PIN. You will need it every time you open this app.", null
        ) { pin ->
            showQuestion("STEP 1 OF 3", null) { qi, ans ->
                Store.setPin(this, pin)
                Store.setQuestion(this, qi, ans)
                unlocked = true
                route()
            }
        }
    }

    private fun showQuestion(step: String?, onBack: (() -> Unit)?, onSave: (Int, String) -> Unit) {
        val col = column()
        if (step != null) col.addView(stepView(step))
        val h = Ui.tv(this, "Security question", 28f, Color.WHITE, true)
        val hl = Ui.lp(Ui.WRAP, Ui.WRAP)
        hl.topMargin = dp(8)
        col.addView(h, hl)
        val sub = Ui.tv(this, "If you forget your PIN, this is the only way back in.", 16f, Palette.MUTED)
        val sl = Ui.lp(Ui.WRAP, Ui.WRAP)
        sl.topMargin = dp(8)
        col.addView(sub, sl)

        var sel = 0
        val opts = ArrayList<TextView>()
        fun paint() {
            for (i in opts.indices) {
                val on = i == sel
                opts[i].background = Ui.rect(this, Palette.CARD, 14, if (on) Palette.CYAN else Palette.BORDER)
                opts[i].setTextColor(if (on) Color.WHITE else Palette.MUTED)
            }
        }
        for (i in questions.indices) {
            val o = Ui.tv(this, questions[i], 16f, Palette.MUTED)
            o.setPadding(dp(16), dp(14), dp(16), dp(14))
            o.setOnClickListener {
                sel = i
                paint()
            }
            opts.add(o)
            val ol = Ui.lp(Ui.MATCH, Ui.WRAP)
            ol.topMargin = dp(10)
            col.addView(o, ol)
        }
        paint()
        val et = field("Your answer")
        val el = Ui.lp(Ui.MATCH, dp(52))
        el.topMargin = dp(16)
        col.addView(et, el)
        val save = Ui.primary(this, "Save") {
            val a = et.text.toString().trim()
            if (a.length < 2) toast("Please type an answer") else onSave(sel, a)
        }
        val bl = Ui.lp(Ui.MATCH, dp(52))
        bl.topMargin = dp(20)
        col.addView(save, bl)
        setScreen(scroll(col))
        back = onBack
    }

    private fun showForgot() {
        if (Store.questionIndex(this) < 0) {
            toast("No security question was set")
            return
        }
        val col = column()
        col.addView(circleBtn("back", "Back") { showGate() }, Ui.lp(dp(40), dp(40)))
        val h = Ui.tv(this, "Reset your PIN", 28f, Color.WHITE, true)
        val hl = Ui.lp(Ui.WRAP, Ui.WRAP)
        hl.topMargin = dp(24)
        col.addView(h, hl)
        val sub = Ui.tv(this, "Answer your security question to set a new PIN.", 16f, Palette.MUTED)
        val sl = Ui.lp(Ui.WRAP, Ui.WRAP)
        sl.topMargin = dp(8)
        col.addView(sub, sl)
        val qc = Ui.card(this)
        qc.addView(Ui.tv(this, "Your question", 13f, Palette.MUTED))
        qc.addView(Ui.tv(this, questions[Store.questionIndex(this).coerceIn(0, questions.size - 1)], 18f, Color.WHITE, true))
        val ql = Ui.lp(Ui.MATCH, Ui.WRAP)
        ql.topMargin = dp(22)
        col.addView(qc, ql)
        val et = field("Your answer")
        val el = Ui.lp(Ui.MATCH, dp(52))
        el.topMargin = dp(14)
        col.addView(et, el)
        val vb = Ui.primary(this, "Verify") {
            val w = Guard.wait()
            if (w > 0) {
                toast("Too many attempts. Try again in " + w + "s")
            } else if (Store.checkAnswer(this, et.text.toString())) {
                Guard.ok()
                pinTwice(null, "Set a new PIN", "Choose a new 6-digit PIN.", { showGate() }) { pin ->
                    Store.setPin(this, pin)
                    unlocked = true
                    route()
                }
            } else {
                Guard.fail()
                toast("That answer is not correct")
            }
        }
        val vl = Ui.lp(Ui.MATCH, dp(52))
        vl.topMargin = dp(18)
        col.addView(vb, vl)
        setScreen(scroll(col))
        back = { showGate() }
    }

    // ---------- permissions ----------

    private fun permCard(
        num: String, title: String, desc: String, doneText: String, done: Boolean,
        btn: String?, primary: Boolean, action: (() -> Unit)?
    ): View {
        val card = Ui.card(this)
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val ci = FrameLayout(this)
        ci.background = Ui.oval(if (done) Palette.GREEN else Palette.LINE)
        if (done) {
            ci.addView(IconView(this, "check", Color.WHITE), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        } else {
            ci.addView(Ui.tv(this, num, 16f, Color.WHITE, true), FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER))
        }
        head.addView(ci, Ui.lp(dp(40), dp(40)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        tx.addView(Ui.tv(this, title, 17f, Color.WHITE, true))
        tx.addView(Ui.tv(this, if (done) doneText else desc, 14f, Palette.MUTED))
        val tl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        tl.leftMargin = dp(12)
        head.addView(tx, tl)
        card.addView(head)
        if (!done && btn != null && action != null) {
            val b = if (primary) Ui.primary(this, btn) { action() } else Ui.outline(this, btn) { action() }
            val bl = Ui.lp(Ui.MATCH, dp(48))
            bl.topMargin = dp(14)
            card.addView(b, bl)
        }
        return card
    }

    private fun showPerms() {
        val usage = hasUsage()
        val overlay = Settings.canDrawOverlays(this)
        val col = column()
        val bars = LinearLayout(this)
        for (i in 0 until 3) {
            val v = View(this)
            v.background = Ui.rect(this, if (i < 2) Palette.CYAN else Palette.LINE, 2)
            val l = LinearLayout.LayoutParams(0, dp(4), 1f)
            if (i > 0) l.leftMargin = dp(8)
            bars.addView(v, l)
        }
        col.addView(bars, Ui.lp(Ui.MATCH, Ui.WRAP))
        val stl = Ui.lp(Ui.WRAP, Ui.WRAP)
        stl.topMargin = dp(16)
        col.addView(stepView("STEP 2 OF 3"), stl)
        val hl = Ui.lp(Ui.WRAP, Ui.WRAP)
        hl.topMargin = dp(8)
        col.addView(Ui.tv(this, "Allow permissions", 28f, Color.WHITE, true), hl)
        val sl = Ui.lp(Ui.WRAP, Ui.WRAP)
        sl.topMargin = dp(8)
        col.addView(Ui.tv(this, "AruShield needs these to notice and cover your locked apps.", 16f, Palette.MUTED), sl)

        val cards = ArrayList<View>()
        cards.add(permCard("1", "PIN created", "", "Done", true, null, false, null))
        cards.add(permCard("2", "Usage access", "Detects which app you open", "Allowed", usage, "Allow", true) {
            detour = true
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        cards.add(permCard("3", "Display over other apps", "Shows the lock screen on top", "Allowed", overlay, "Allow", true) {
            detour = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        })
        cards.add(permCard("4", "Keep running (recommended)", "Stops the phone from closing AruShield in the background", "", false, "Open battery settings", false) {
            detour = true
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        for (c in cards) {
            val cl = Ui.lp(Ui.MATCH, Ui.WRAP)
            cl.topMargin = dp(14)
            col.addView(c, cl)
        }
        col.addView(View(this), Ui.lp(Ui.MATCH, dp(20)))
        val cont = Ui.primary(this, "Continue") {
            Store.setOnboarded(this, true)
            route()
        }
        if (!(usage && overlay)) {
            cont.isEnabled = false
            cont.alpha = 0.4f
        }
        col.addView(cont, Ui.lp(Ui.MATCH, dp(52)))
        setScreen(scroll(col))
    }

    // ---------- main shell ----------

    private fun showMain(t: Int) {
        tab = t
        if (hasUsage() && Settings.canDrawOverlays(this)) WatchService.start(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = Ui.bg()
        val content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        val page: View = when (t) {
            0 -> homeTab()
            1 -> appsTab()
            else -> settingsTab()
        }
        content.addView(page)
        root.addView(navBar(t), Ui.lp(Ui.MATCH, dp(64)))
        setScreen(root)
    }

    private fun navBar(sel: Int): View {
        val bar = LinearLayout(this)
        bar.setBackgroundColor(0xFF080E27.toInt())
        val names = arrayOf("Home", "Apps", "Settings")
        val icons = arrayOf("home", "apps", "gear")
        for (i in 0 until 3) {
            val col = if (i == sel) Palette.CYAN else Palette.MUTED
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.addView(IconView(this, icons[i], col), Ui.lp(dp(22), dp(22)))
            val ll = Ui.lp(Ui.WRAP, Ui.WRAP)
            ll.topMargin = dp(3)
            item.addView(Ui.tv(this, names[i], 12f, col), ll)
            item.setOnClickListener { showMain(i) }
            bar.addView(item, LinearLayout.LayoutParams(0, Ui.MATCH, 1f))
        }
        return bar
    }

    private fun homeTab(): View {
        val n = Store.locked(this).size
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(36), dp(20), dp(16))

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(LogoView(this), Ui.lp(dp(34), dp(34)))
        val bn = Ui.brand(this, 22f)
        val bl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        bl.leftMargin = dp(10)
        head.addView(bn, bl)
        head.addView(circleBtn("gear", "Settings") { showMain(2) }, Ui.lp(dp(40), dp(40)))
        col.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP))

        val ring = FrameLayout(this)
        ring.addView(RingView(this), FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        inner.gravity = Gravity.CENTER
        inner.addView(LogoView(this), Ui.lp(dp(56), dp(56)))
        val ct = Ui.tv(this, if (n == 1) "1 App Locked" else "" + n + " Apps Locked", 20f, Color.WHITE, true)
        val ctl = Ui.lp(Ui.WRAP, Ui.WRAP)
        ctl.topMargin = dp(10)
        inner.addView(ct, ctl)
        inner.addView(Ui.tv(this, if (Store.enabled(this)) "Your device is protected" else "Protection is paused", 12f, Palette.MUTED))
        ring.addView(inner, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        val rl = Ui.lp(dp(240), dp(240))
        rl.topMargin = dp(24)
        col.addView(ring, rl)

        val b1 = Ui.primary(this, "+  Lock Apps") { showMain(1) }
        val b1l = Ui.lp(Ui.MATCH, dp(52))
        b1l.topMargin = dp(24)
        col.addView(b1, b1l)
        val b2 = Ui.outline(this, "Manage Locked Apps") { showManage() }
        val b2l = Ui.lp(Ui.MATCH, dp(52))
        b2l.topMargin = dp(12)
        col.addView(b2, b2l)

        val tiles = LinearLayout(this)
        val names = arrayOf("Secure\nApps", "Privacy\nFirst", "100%\nSafe")
        val icons = arrayOf("lock", "eye", "shield")
        for (i in 0 until 3) {
            val tcard = Ui.card(this)
            tcard.gravity = Gravity.CENTER_HORIZONTAL
            tcard.setPadding(dp(8), dp(14), dp(8), dp(14))
            tcard.addView(IconView(this, icons[i], Palette.CYAN), Ui.lp(dp(26), dp(26)))
            val tt = Ui.tv(this, names[i], 12f, Color.WHITE)
            tt.gravity = Gravity.CENTER
            val ttl = Ui.lp(Ui.WRAP, Ui.WRAP)
            ttl.topMargin = dp(8)
            tcard.addView(tt, ttl)
            val tl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            if (i > 0) tl.leftMargin = dp(10)
            tiles.addView(tcard, tl)
        }
        val tsl = Ui.lp(Ui.MATCH, Ui.WRAP)
        tsl.topMargin = dp(24)
        col.addView(tiles, tsl)
        return scroll(col)
    }

    // ---------- app lists ----------

    private fun categoryOf(pkg: String): String {
        return try {
            when (packageManager.getApplicationInfo(pkg, 0).category) {
                ApplicationInfo.CATEGORY_SOCIAL -> "Social"
                ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_IMAGE -> "Media"
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
                ApplicationInfo.CATEGORY_GAME -> "Game"
                ApplicationInfo.CATEGORY_NEWS -> "News"
                ApplicationInfo.CATEGORY_MAPS -> "Maps"
                else -> "App"
            }
        } catch (e: Exception) {
            "App"
        }
    }

    private fun appListBlock(withTabs: Boolean): View {
        val pm = packageManager
        val locked0 = Store.locked(this)
        val all = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedWith(compareBy<Pair<String, String>>({ it.first !in locked0 }, { it.second.lowercase() }))

        var query = ""
        var seg = 0
        val items = ArrayList<Pair<String, String>>()
        fun rebuild() {
            items.clear()
            val ls = Store.locked(this)
            for (a in all) {
                val on = a.first in ls
                if (seg == 1 && !on) continue
                if (seg == 2 && on) continue
                if (query.isNotBlank() && !a.second.lowercase().contains(query.lowercase())) continue
                items.add(a)
            }
        }
        rebuild()

        val adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun isEnabled(p: Int) = false
            override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
                val pkg = items[p].first
                val name = items[p].second
                val row = LinearLayout(this@MainActivity)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(4), dp(9), dp(4), dp(9))
                val icon = ImageView(this@MainActivity)
                try { icon.setImageDrawable(pm.getApplicationIcon(pkg)) } catch (e: Exception) { }
                row.addView(icon, Ui.lp(dp(40), dp(40)))
                val tx = LinearLayout(this@MainActivity)
                tx.orientation = LinearLayout.VERTICAL
                tx.addView(Ui.tv(this@MainActivity, name, 15f, Color.WHITE, true))
                tx.addView(Ui.tv(this@MainActivity, categoryOf(pkg), 12f, Palette.MUTED))
                val txl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
                txl.leftMargin = dp(12)
                row.addView(tx, txl)
                val lk = IconView(this@MainActivity, "lock", Palette.BLUE)
                lk.visibility = if (pkg in Store.locked(this@MainActivity)) View.VISIBLE else View.INVISIBLE
                val lkl = Ui.lp(dp(18), dp(18))
                lkl.rightMargin = dp(10)
                row.addView(lk, lkl)
                val sw = Toggle(this@MainActivity, pkg in Store.locked(this@MainActivity)) { on ->
                    Store.setLocked(this@MainActivity, pkg, on)
                    lk.visibility = if (on) View.VISIBLE else View.INVISIBLE
                    if (seg != 0) {
                        host.postDelayed({
                            rebuild()
                            notifyDataSetChanged()
                        }, 250)
                    }
                }
                sw.contentDescription = "Lock " + name
                row.addView(sw, Ui.lp(dp(46), dp(28)))
                return row
            }
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val sf = field("Search apps...")
        sf.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                rebuild()
                adapter.notifyDataSetChanged()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) { }
            override fun onTextChanged(s: CharSequence?, st: Int, bf: Int, c: Int) { }
        })
        col.addView(sf, Ui.lp(Ui.MATCH, dp(48)))

        if (withTabs) {
            val segBar = LinearLayout(this)
            segBar.background = Ui.rect(this, Palette.CARD, 22, Palette.BORDER)
            segBar.setPadding(dp(3), dp(3), dp(3), dp(3))
            val labels = arrayOf("All Apps", "Locked", "Unlocked")
            val views = ArrayList<TextView>()
            fun paintSeg() {
                for (i in views.indices) {
                    val on = i == seg
                    views[i].background = if (on) Ui.pill(this) else null
                    views[i].setTextColor(if (on) Color.WHITE else Palette.MUTED)
                }
            }
            for (i in labels.indices) {
                val tv = Ui.tv(this, labels[i], 14f, Palette.MUTED, true)
                tv.gravity = Gravity.CENTER
                tv.setOnClickListener {
                    seg = i
                    paintSeg()
                    rebuild()
                    adapter.notifyDataSetChanged()
                }
                views.add(tv)
                segBar.addView(tv, LinearLayout.LayoutParams(0, dp(36), 1f))
            }
            paintSeg()
            val sgl = Ui.lp(Ui.MATCH, Ui.WRAP)
            sgl.topMargin = dp(12)
            col.addView(segBar, sgl)
        }

        val lv = ListView(this)
        lv.divider = null
        lv.adapter = adapter
        lv.isVerticalScrollBarEnabled = false
        val lvl = LinearLayout.LayoutParams(Ui.MATCH, 0, 1f)
        lvl.topMargin = dp(8)
        col.addView(lv, lvl)
        return col
    }

    private fun appsTab(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(8))
        col.addView(Ui.tv(this, "Locked Apps", 24f, Color.WHITE, true))
        val bl = LinearLayout.LayoutParams(Ui.MATCH, 0, 1f)
        bl.topMargin = dp(14)
        col.addView(appListBlock(true), bl)
        return col
    }

    private fun showManage() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(20))
        col.background = Ui.bg()
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(circleBtn("back", "Back") { showMain(0) }, Ui.lp(dp(40), dp(40)))
        val ht = Ui.tv(this, "Manage Locked Apps", 20f, Color.WHITE, true)
        val htl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        htl.leftMargin = dp(14)
        head.addView(ht, htl)
        col.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP))
        val bl = LinearLayout.LayoutParams(Ui.MATCH, 0, 1f)
        bl.topMargin = dp(14)
        col.addView(appListBlock(false), bl)
        val done = Ui.primary(this, "Done") { showMain(0) }
        val dl = Ui.lp(Ui.MATCH, dp(52))
        dl.topMargin = dp(10)
        col.addView(done, dl)
        setScreen(col)
        back = { showMain(0) }
    }

    // ---------- settings and about ----------

    private fun chev(): View {
        val v = IconView(this, "chev", Palette.MUTED)
        v.layoutParams = Ui.lp(dp(20), dp(20))
        return v
    }

    private fun row(icon: String, title: String, sub: String?, right: View?, onClick: (() -> Unit)?): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(13), 0, dp(13))
        r.minimumHeight = dp(56)
        r.addView(IconView(this, icon, Palette.MUTED), Ui.lp(dp(22), dp(22)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        tx.addView(Ui.tv(this, title, 15f, Color.WHITE))
        if (sub != null) tx.addView(Ui.tv(this, sub, 12f, Palette.MUTED))
        val txl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        txl.leftMargin = dp(14)
        r.addView(tx, txl)
        if (right is Toggle) r.addView(right, Ui.lp(dp(46), dp(28))) else if (right != null) r.addView(right)
        if (onClick != null) r.setOnClickListener { onClick() }
        return r
    }

    private fun group(label: String, rows: List<View>): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val lab = Ui.tv(this, label, 13f, Palette.CYAN, true)
        lab.setPadding(dp(4), 0, 0, dp(8))
        box.addView(lab)
        val g = LinearLayout(this)
        g.orientation = LinearLayout.VERTICAL
        g.setPadding(dp(16), 0, dp(16), 0)
        g.background = Ui.rect(this, Palette.CARD, 18, Palette.BORDER)
        for ((i, r) in rows.withIndex()) {
            if (i > 0) {
                val d = View(this)
                d.setBackgroundColor(Palette.LINE)
                g.addView(d, Ui.lp(Ui.MATCH, 1))
            }
            g.addView(r, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        box.addView(g)
        return box
    }

    private fun settingsTab(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(20))
        col.addView(Ui.tv(this, "Settings", 24f, Color.WHITE, true))
        val dm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val cn = ComponentName(this, AdminReceiver::class.java)
        val modes = arrayOf("Immediately", "After 1 min", "After 5 min")

        val sec = ArrayList<View>()
        sec.add(row("shield", "Protection", "Turn all app locks on or off", Toggle(this, Store.enabled(this)) { Store.setEnabled(this, it) }, null))
        sec.add(row("lock", "Change PIN", null, chev()) { changePin() })
        sec.add(row("info", "Security Question", null, chev()) {
            showQuestion(null, { showMain(2) }) { qi, ans ->
                Store.setQuestion(this, qi, ans)
                toast("Security question saved")
                showMain(2)
            }
        })
        if (Ui.hasFinger(this)) {
            sec.add(row("finger", "Fingerprint", null, Toggle(this, Store.finger(this)) { Store.setFinger(this, it) }, null))
        }
        val av = LinearLayout(this)
        av.gravity = Gravity.CENTER_VERTICAL
        av.addView(Ui.tv(this, modes[Store.autolock(this).coerceIn(0, 2)], 13f, Palette.MUTED))
        av.addView(chev())
        sec.add(row("clock", "Auto Lock", null, av) {
            Store.setAutolock(this, (Store.autolock(this) + 1) % 3)
            showMain(2)
        })
        val adminOn = dm.isAdminActive(cn)
        sec.add(row("shield", "Uninstall Protection", "Stops others from removing this app", Toggle(this, adminOn) { on ->
            if (on) {
                detour = true
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
                i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "This stops others from uninstalling AruShield.")
                startActivity(i)
            } else {
                try { dm.removeActiveAdmin(cn) } catch (e: Exception) { }
            }
        }, null))
        val g1 = Ui.lp(Ui.MATCH, Ui.WRAP)
        g1.topMargin = dp(18)
        col.addView(group("Security", sec), g1)

        val gen = ArrayList<View>()
        gen.add(row("bell", "Notifications", null, chev()) {
            detour = true
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(i)
        })
        val g2 = Ui.lp(Ui.MATCH, Ui.WRAP)
        g2.topMargin = dp(18)
        col.addView(group("General", gen), g2)

        val ab = ArrayList<View>()
        ab.add(row("info", "About AruShield", null, chev()) { showAbout() })
        ab.add(row("doc", "Privacy Policy", null, chev()) {
            AlertDialog.Builder(this)
                .setTitle("Privacy Policy")
                .setMessage("AruShield keeps your PIN, security answer and settings only on this phone. The app has no internet access and collects no data.")
                .setPositiveButton("OK", null)
                .show()
        })
        val g3 = Ui.lp(Ui.MATCH, Ui.WRAP)
        g3.topMargin = dp(18)
        col.addView(group("About", ab), g3)
        return scroll(col)
    }

    private fun showAbout() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(40), dp(20), dp(24))
        col.background = Ui.bg()
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(circleBtn("back", "Back") { showMain(2) }, Ui.lp(dp(40), dp(40)))
        val htl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        htl.leftMargin = dp(14)
        head.addView(Ui.tv(this, "About AruShield", 20f, Color.WHITE, true), htl)
        col.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP))
        val ll = Ui.lp(dp(100), dp(100))
        ll.topMargin = dp(24)
        col.addView(LogoView(this), ll)
        val aboutBrand = Ui.brand(this, 28f)
        val aboutBrandLp = Ui.lp(Ui.MATCH, Ui.WRAP)
        aboutBrandLp.topMargin = dp(8)
        col.addView(aboutBrand, aboutBrandLp)
        val v = Ui.tv(this, "Version 1.0.0", 13f, Palette.MUTED)
        val vl = Ui.lp(Ui.WRAP, Ui.WRAP)
        vl.topMargin = dp(4)
        col.addView(v, vl)
        val tg = Ui.tv(this, "Your Privacy, Our Priority", 15f, Color.WHITE)
        val tgl = Ui.lp(Ui.WRAP, Ui.WRAP)
        tgl.topMargin = dp(14)
        col.addView(tg, tgl)
        val names = arrayOf("Secure", "Private", "Fast", "Reliable")
        val subs = arrayOf("Lock your apps and data", "No data is collected", "Lightweight and smooth", "Built for your security")
        val icons = arrayOf("lock", "eye", "bolt", "shield")
        for (i in 0 until 4) {
            val c = Ui.card(this)
            c.orientation = LinearLayout.HORIZONTAL
            c.gravity = Gravity.CENTER_VERTICAL
            c.setPadding(dp(14), dp(12), dp(14), dp(12))
            val ic = FrameLayout(this)
            ic.background = Ui.oval(Palette.KEY, Palette.KEYRING, dp(1))
            ic.addView(IconView(this, icons[i], Palette.CYAN), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
            c.addView(ic, Ui.lp(dp(40), dp(40)))
            val tx = LinearLayout(this)
            tx.orientation = LinearLayout.VERTICAL
            tx.addView(Ui.tv(this, names[i], 15f, Color.WHITE, true))
            tx.addView(Ui.tv(this, subs[i], 12f, Palette.MUTED))
            val txl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            txl.leftMargin = dp(12)
            c.addView(tx, txl)
            val cl = Ui.lp(Ui.MATCH, Ui.WRAP)
            cl.topMargin = dp(10)
            col.addView(c, cl)
        }
        val ft = Ui.tv(this, "Made with \u2665 for a safer digital life", 12f, Palette.MUTED)
        val ftl = Ui.lp(Ui.WRAP, Ui.WRAP)
        ftl.topMargin = dp(20)
        col.addView(ft, ftl)
        setScreen(scroll(col))
        back = { showMain(2) }
    }

    private fun changePin() {
        pinScreen(null, "Enter current PIN", "Confirm it is you before changing.", null) { pad, p ->
            if (Ui.verify(this, pad, p)) {
                pinTwice(null, "Enter new PIN", "Choose a new 6-digit PIN.", { showMain(2) }) { np ->
                    Store.setPin(this, np)
                    toast("PIN changed")
                    showMain(2)
                }
            }
        }
        back = { showMain(2) }
    }
}
