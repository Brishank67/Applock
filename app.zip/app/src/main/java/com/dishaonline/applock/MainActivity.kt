package com.dishaonline.applock

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        var unlocked = false
        var detour = false
    }

    private lateinit var host: FrameLayout
    private var tab = 0
    private var back: (() -> Unit)? = null
    private var cancel: CancellationSignal? = null

    private val questions = arrayOf(
        "What is your pet's name?",
        "What was your first school's name?",
        "In which city were you born?",
        "What is your favourite teacher's name?"
    )

    private fun dp(n: Int) = Ui.dp(this, n)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = Palette.BG
        window.navigationBarColor = Palette.BG
        host = FrameLayout(this)
        host.setBackgroundColor(Palette.BG)
        setContentView(host)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        route()
    }

    override fun onStop() {
        super.onStop()
        if (detour) detour = false else unlocked = false
    }

    override fun onDestroy() {
        cancel?.cancel()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = back
        if (b != null) b() else finish()
    }

    // ---------- routing ----------

    private fun hasUsage(): Boolean {
        val a = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return a.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun route() {
        cancel?.cancel()
        cancel = null
        if (!Store.hasPin(this)) {
            createFlow()
        } else if (!unlocked) {
            showGate()
        } else if (!(hasUsage() && Settings.canDrawOverlays(this)) || !Store.onboarded(this)) {
            showPerms()
        } else {
            showMain(tab)
        }
    }

    private fun setScreen(v: View) {
        back = null
        host.removeAllViews()
        host.addView(v, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun scroll(v: View): View {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(v, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        return sv
    }

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(24), dp(56), dp(24), dp(24))
        return c
    }

    private fun stepView(s: String): TextView {
        val t = Ui.tv(this, s, 13f, Palette.MUTED)
        t.letterSpacing = 0.08f
        return t
    }

    private fun linkBtn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setAllCaps(false)
        b.setTextColor(Palette.SOFT)
        b.background = null
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(Palette.MUTED)
        e.setTextColor(Color.WHITE)
        e.textSize = 16f
        e.setPadding(dp(16), 0, dp(16), 0)
        e.background = Ui.rect(Palette.CARD, dp(14).toFloat())
        e.inputType = InputType.TYPE_CLASS_TEXT
        e.isSingleLine = true
        return e
    }

    // ---------- PIN screens ----------

    private fun lockBox(): View {
        val t = Palette.cur(this)
        val f = FrameLayout(this)
        f.background = Ui.grad(t.a, t.b, dp(24).toFloat())
        f.addView(IconView(this, "lock", Color.WHITE), FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        f.layoutParams = Ui.lp(dp(88), dp(88))
        return f
    }

    private fun pinScreen(
        top: View?, title: String, sub: String, finger: Boolean, footer: View?,
        onDone: (PinPad, String) -> Unit
    ) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(32), dp(56), dp(32), dp(24))
        root.background = Ui.bg(this)
        if (top != null) root.addView(top)
        val t1 = Ui.tv(this, title, 24f, Color.WHITE, true)
        t1.gravity = Gravity.CENTER
        val l1 = Ui.lp(Ui.WRAP, Ui.WRAP)
        l1.topMargin = dp(20)
        root.addView(t1, l1)
        val t2 = Ui.tv(this, sub, 15f, Palette.MUTED)
        t2.gravity = Gravity.CENTER
        val l2 = Ui.lp(Ui.WRAP, Ui.WRAP)
        l2.topMargin = dp(6)
        root.addView(t2, l2)
        var pad: PinPad? = null
        pad = PinPad(this, finger, { askFinger() }, { p -> onDone(pad!!, p) })
        root.addView(pad)
        if (footer != null) root.addView(footer)
        setScreen(scroll(root))
    }

    private fun askFinger() {
        cancel?.cancel()
        cancel = Ui.finger(this, "Unlock App Lock") {
            unlocked = true
            route()
        }
    }

    private fun showGate() {
        val fin = Ui.fingerOk(this)
        val forgot = linkBtn("Forgot PIN?") { showForgot() }
        forgot.layoutParams = Ui.lp(Ui.WRAP, dp(44))
        pinScreen(lockBox(), "App Lock", "Enter your PIN to open the app", fin, forgot) { pad, p ->
            if (Ui.verify(this, pad, p)) {
                unlocked = true
                route()
            }
        }
        if (fin) host.post { askFinger() }
    }

    private fun pinTwice(
        step: String?, t1: String, s1: String, onBack: (() -> Unit)?, onSet: (String) -> Unit
    ) {
        pinScreen(if (step == null) null else stepView(step), t1, s1, false, null) { _, first ->
            pinScreen(
                if (step == null) null else stepView(step),
                "Confirm your PIN", "Enter the same PIN again.", false, null
            ) { pad2, second ->
                if (second == first) {
                    onSet(first)
                } else {
                    pad2.wrong()
                    toast("PINs do not match")
                    host.postDelayed({ pinTwice(step, t1, s1, onBack, onSet) }, 600)
                }
            }
            back = { pinTwice(step, t1, s1, onBack, onSet) }
        }
        back = onBack
    }

    private fun createFlow() {
        pinTwice(
            "STEP 1 OF 3", "Create your PIN",
            "Choose a 4-digit PIN. You will need it every time you open this app.", null
        ) { pin ->
            showQuestion("STEP 1 OF 3", null) { qi, ans ->
                Store.setPin(this, pin)
                Store.setQuestion(this, qi, ans)
                unlocked = true
                route()
            }
        }
    }

    private fun showQuestion(step: String?, onBack: (() -> Unit)?, onSave: (Int, String) -> Unit) {
        val col = column()
        if (step != null) col.addView(stepView(step))
        val h = Ui.tv(this, "Security question", 28f, Color.WHITE, true)
        val hl = Ui.lp(Ui.WRAP, Ui.WRAP)
        hl.topMargin = dp(8)
        col.addView(h, hl)
        val sub = Ui.tv(this, "If you forget your PIN, this is the only way back in.", 16f, Palette.MUTED)
        val sl = Ui.lp(Ui.WRAP, Ui.WRAP)
        sl.topMargin = dp(8)
        col.addView(sub, sl)

        var sel = 0
        val opts = ArrayList<TextView>()
        val acc = Palette.cur(this).a
        fun paint() {
            for (i in opts.indices) {
                val on = i == sel
                val g = GradientDrawable()
                g.cornerRadius = dp(14).toFloat()
                g.setColor(Palette.CARD)
                if (on) g.setStroke(dp(2), acc)
                opts[i].background = g
                opts[i].setTextColor(if (on) Color.WHITE else Palette.MUTED)
            }
        }
        for (i in questions.indices) {
            val o = Ui.tv(this, questions[i], 16f, Palette.MUTED)
            o.setPadding(dp(16), dp(14), dp(16), dp(14))
            o.setOnClickListener {
                sel = i
                paint()
            }
            opts.add(o)
            val ol = Ui.lp(Ui.MATCH, Ui.WRAP)
            ol.topMargin = dp(10)
            col.addView(o, ol)
        }
        paint()
        val et = field("Your answer")
        val el = Ui.lp(Ui.MATCH, dp(52))
        el.topMargin = dp(16)
        col.addView(et, el)
        val save = Ui.primary(this, "Save") {
            val a = et.text.toString().trim()
            if (a.length < 2) toast("Please type an answer") else onSave(sel, a)
        }
        val bl = Ui.lp(Ui.MATCH, dp(56))
        bl.topMargin = dp(20)
        col.addView(save, bl)
        setScreen(scroll(col))
        back = onBack
    }

    private fun showForgot() {
        if (Store.questionIndex(this) < 0) {
            toast("No security question was set")
            return
        }
        val col = column()
        val bk = FrameLayout(this)
        bk.background = Ui.rect(Palette.CARD, dp(14).toFloat())
        bk.addView(IconView(this, "back", Color.WHITE), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        bk.contentDescription = "Back"
        bk.setOnClickListener { showGate() }
        col.addView(bk, Ui.lp(dp(44), dp(44)))
        val h = Ui.tv(this, "Reset your PIN", 28f, Color.WHITE, true)
        val hl = Ui.lp(Ui.WRAP, Ui.WRAP)
        hl.topMargin = dp(24)
        col.addView(h, hl)
        val sub = Ui.tv(this, "Answer your security question to set a new PIN.", 16f, Palette.MUTED)
        val sl = Ui.lp(Ui.WRAP, Ui.WRAP)
        sl.topMargin = dp(8)
        col.addView(sub, sl)
        val qc = Ui.card(this)
        qc.addView(Ui.tv(this, "Your question", 13f, Palette.MUTED))
        qc.addView(Ui.tv(this, questions[Store.questionIndex(this).coerceIn(0, questions.size - 1)], 18f, Color.WHITE, true))
        val ql = Ui.lp(Ui.MATCH, Ui.WRAP)
        ql.topMargin = dp(22)
        col.addView(qc, ql)
        val et = field("Your answer")
        val el = Ui.lp(Ui.MATCH, dp(52))
        el.topMargin = dp(14)
        col.addView(et, el)
        val vb = Ui.primary(this, "Verify") {
            val w = Guard.wait()
            if (w > 0) {
                toast("Too many attempts. Try again in " + w + "s")
            } else if (Store.checkAnswer(this, et.text.toString())) {
                Guard.ok()
                pinTwice(null, "Set a new PIN", "Choose a new 4-digit PIN.", { showGate() }) { pin ->
                    Store.setPin(this, pin)
                    unlocked = true
                    route()
                }
            } else {
                Guard.fail()
                toast("That answer is not correct")
            }
        }
        val vl = Ui.lp(Ui.MATCH, dp(56))
        vl.topMargin = dp(18)
        col.addView(vb, vl)
        setScreen(scroll(col))
        back = { showGate() }
    }

    // ---------- permissions ----------

    private fun permCard(
        num: String, title: String, desc: String, doneText: String, done: Boolean,
        btn: String?, primary: Boolean, action: (() -> Unit)?
    ): View {
        val card = Ui.card(this)
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val ci = FrameLayout(this)
        ci.background = Ui.oval(if (done) Palette.GREEN else Palette.LINE)
        if (done) {
            ci.addView(IconView(this, "check", Color.WHITE), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        } else {
            ci.addView(Ui.tv(this, num, 16f, Color.WHITE, true), FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER))
        }
        head.addView(ci, Ui.lp(dp(40), dp(40)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        tx.addView(Ui.tv(this, title, 17f, Color.WHITE, true))
        tx.addView(Ui.tv(this, if (done) doneText else desc, 14f, Palette.MUTED))
        val tl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        tl.leftMargin = dp(12)
        head.addView(tx, tl)
        card.addView(head)
        if (!done && btn != null && action != null) {
            val b = if (primary) Ui.primary(this, btn) { action() } else Ui.outline(this, btn) { action() }
            val bl = Ui.lp(Ui.MATCH, dp(48))
            bl.topMargin = dp(14)
            card.addView(b, bl)
        }
        return card
    }

    private fun showPerms() {
        val usage = hasUsage()
        val overlay = Settings.canDrawOverlays(this)
        val acc = Palette.cur(this).a
        val col = column()
        val bars = LinearLayout(this)
        for (i in 0 until 3) {
            val v = View(this)
            v.background = Ui.rect(if (i < 2) acc else Palette.LINE, dp(2).toFloat())
            val l = LinearLayout.LayoutParams(0, dp(4), 1f)
            if (i > 0) l.leftMargin = dp(8)
            bars.addView(v, l)
        }
        col.addView(bars, Ui.lp(Ui.MATCH, Ui.WRAP))
        val st = stepView("STEP 2 OF 3")
        val stl = Ui.lp(Ui.WRAP, Ui.WRAP)
        stl.topMargin = dp(16)
        col.addView(st, stl)
        val h = Ui.tv(this, "Allow permissions", 28f, Color.WHITE, true)
        val hl = Ui.lp(Ui.WRAP, Ui.WRAP)
        hl.topMargin = dp(8)
        col.addView(h, hl)
        val sub = Ui.tv(this, "App Lock needs these to notice and cover your locked apps.", 16f, Palette.MUTED)
        val sl = Ui.lp(Ui.WRAP, Ui.WRAP)
        sl.topMargin = dp(8)
        col.addView(sub, sl)

        val cards = ArrayList<View>()
        cards.add(permCard("1", "PIN created", "", "Done", true, null, false, null))
        cards.add(permCard("2", "Usage access", "Detects which app you open", "Allowed", usage, "Allow", true) {
            detour = true
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        cards.add(permCard("3", "Display over other apps", "Shows the lock screen on top", "Allowed", overlay, "Allow", true) {
            detour = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        })
        cards.add(permCard("4", "Keep running (recommended)", "Stops the phone from closing App Lock in the background", "", false, "Open battery settings", false) {
            detour = true
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        for (c in cards) {
            val cl = Ui.lp(Ui.MATCH, Ui.WRAP)
            cl.topMargin = dp(14)
            col.addView(c, cl)
        }
        val space = View(this)
        col.addView(space, Ui.lp(Ui.MATCH, dp(20)))
        val cont = Ui.primary(this, "Continue") {
            Store.setOnboarded(this, true)
            route()
        }
        if (!(usage && overlay)) {
            cont.isEnabled = false
            cont.alpha = 0.4f
        }
        col.addView(cont, Ui.lp(Ui.MATCH, dp(56)))
        setScreen(scroll(col))
    }

    // ---------- main shell ----------

    private fun showMain(t: Int) {
        tab = t
        if (hasUsage() && Settings.canDrawOverlays(this)) WatchService.start(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        val page: View = when (t) {
            0 -> appsTab()
            1 -> themesTab()
            else -> settingsTab()
        }
        content.addView(page)
        root.addView(navBar(t), Ui.lp(Ui.MATCH, dp(72)))
        setScreen(root)
    }

    private fun navBar(sel: Int): View {
        val bar = LinearLayout(this)
        bar.setBackgroundColor(0xFF151834.toInt())
        val names = arrayOf("Apps", "Themes", "Settings")
        val icons = arrayOf("apps", "palette", "gear")
        for (i in 0 until 3) {
            val col = if (i == sel) Palette.SOFT else Palette.MUTED
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.addView(IconView(this, icons[i], col), Ui.lp(dp(22), dp(22)))
            val label = Ui.tv(this, names[i], 12f, col)
            val ll = Ui.lp(Ui.WRAP, Ui.WRAP)
            ll.topMargin = dp(4)
            item.addView(label, ll)
            item.setOnClickListener { showMain(i) }
            bar.addView(item, LinearLayout.LayoutParams(0, Ui.MATCH, 1f))
        }
        return bar
    }

    private fun appsTab(): View {
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val hints = listOf(
            "whatsapp", "gallery", "photo", "message", "mms", "sms", "bank", "pay", "upi",
            "instagram", "facebook", "telegram", "snapchat", "gmail", "mail", "drive",
            "contacts", "wallet", "finance", "vault"
        )
        val sug = apps.filter { a -> hints.any { h -> a.first.lowercase().contains(h) } }
        val rest = apps.filter { a -> !sug.contains(a) }
        val items = ArrayList<Any>()
        var query = ""
        fun rebuild() {
            items.clear()
            if (query.isBlank()) {
                if (sug.isNotEmpty()) {
                    items.add("Suggested apps")
                    items.addAll(sug)
                }
                if (rest.isNotEmpty()) {
                    items.add("All apps")
                    items.addAll(rest)
                }
            } else {
                items.addAll(apps.filter { it.second.lowercase().contains(query.lowercase()) })
            }
        }
        rebuild()

        val t = Palette.cur(this)
        val hero = LinearLayout(this)
        hero.gravity = Gravity.CENTER_VERTICAL
        hero.setPadding(dp(18), dp(18), dp(18), dp(18))
        hero.background = Ui.grad(t.a, t.b, dp(24).toFloat())
        val sh = FrameLayout(this)
        sh.background = Ui.oval(0x33FFFFFF)
        sh.addView(IconView(this, "shield", Color.WHITE), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        hero.addView(sh, Ui.lp(dp(52), dp(52)))
        val txt = LinearLayout(this)
        txt.orientation = LinearLayout.VERTICAL
        val h1 = Ui.tv(this, "", 20f, Color.WHITE, true)
        val h2 = Ui.tv(this, "", 14f, Color.WHITE)
        txt.addView(h1)
        txt.addView(h2)
        val txl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        txl.leftMargin = dp(14)
        hero.addView(txt, txl)
        fun heroUpdate() {
            h1.text = if (Store.enabled(this)) "Protected" else "Paused"
            val n = Store.locked(this).size
            h2.text = if (n == 1) "1 app locked" else "" + n + " apps locked"
        }
        heroUpdate()
        val tg = Toggle(this, Store.enabled(this), true) { on ->
            Store.setEnabled(this, on)
            heroUpdate()
        }
        tg.contentDescription = "App Lock on or off"
        hero.addView(tg, Ui.lp(dp(52), dp(30)))

        val adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getViewTypeCount() = 2
            override fun getItemViewType(p: Int) = if (items[p] is String) 0 else 1
            override fun isEnabled(p: Int) = false
            override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
                val item = items[p]
                if (item is String) {
                    val hd = Ui.tv(this@MainActivity, item.uppercase(), 12f, Palette.MUTED, true)
                    hd.letterSpacing = 0.08f
                    hd.setPadding(dp(16), dp(14), dp(16), dp(4))
                    return hd
                }
                val pr = item as Pair<*, *>
                val pkg = pr.first as String
                val name = pr.second as String
                val row = LinearLayout(this@MainActivity)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(16), dp(8), dp(16), dp(8))
                val icon = ImageView(this@MainActivity)
                try { icon.setImageDrawable(pm.getApplicationIcon(pkg)) } catch (e: Exception) { }
                row.addView(icon, Ui.lp(dp(42), dp(42)))
                val nm = Ui.tv(this@MainActivity, name, 16f, Color.WHITE, true)
                nm.setPadding(dp(14), 0, dp(8), 0)
                row.addView(nm, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                val sw = Toggle(this@MainActivity, Store.locked(this@MainActivity).contains(pkg)) { on ->
                    Store.setLocked(this@MainActivity, pkg, on)
                    heroUpdate()
                }
                sw.contentDescription = "Lock " + name
                row.addView(sw, Ui.lp(dp(46), dp(28)))
                return row
            }
        }

        val sf = field("Search apps")
        sf.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                rebuild()
                adapter.notifyDataSetChanged()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) { }
            override fun onTextChanged(s: CharSequence?, st: Int, bf: Int, c: Int) { }
        })

        val lv = ListView(this)
        lv.divider = null
        lv.adapter = adapter
        lv.isVerticalScrollBarEnabled = false
        val wrap = FrameLayout(this)
        wrap.background = Ui.rect(Palette.CARD, dp(20).toFloat())
        wrap.outlineProvider = ViewOutlineProvider.BACKGROUND
        wrap.clipToOutline = true
        wrap.addView(lv)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(48), dp(20), 0)
        col.addView(Ui.tv(this, "App Lock", 26f, Color.WHITE, true))
        val hl = Ui.lp(Ui.MATCH, Ui.WRAP)
        hl.topMargin = dp(18)
        col.addView(hero, hl)
        val sfl = Ui.lp(Ui.MATCH, dp(48))
        sfl.topMargin = dp(16)
        col.addView(sf, sfl)
        val wl = LinearLayout.LayoutParams(Ui.MATCH, 0, 1f)
        wl.topMargin = dp(14)
        wl.bottomMargin = dp(12)
        col.addView(wrap, wl)
        return col
    }

    private fun themesTab(): View {
        val cur = Store.theme(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(48), dp(20), dp(20))
        col.addView(Ui.tv(this, "Themes", 26f, Color.WHITE, true))
        val sub = Ui.tv(this, "All themes are free. Pick the look of your lock screen.", 15f, Palette.MUTED)
        val sl = Ui.lp(Ui.WRAP, Ui.WRAP)
        sl.topMargin = dp(6)
        col.addView(sub, sl)
        var rowL: LinearLayout? = null
        for ((i, th) in Palette.list.withIndex()) {
            if (i % 2 == 0) {
                rowL = LinearLayout(this)
                val rl = Ui.lp(Ui.MATCH, Ui.WRAP)
                rl.topMargin = dp(14)
                col.addView(rowL, rl)
            }
            val card = FrameLayout(this)
            val inner = LinearLayout(this)
            inner.orientation = LinearLayout.VERTICAL
            inner.setPadding(dp(10), dp(10), dp(10), dp(10))
            val prev = View(this)
            prev.background = Ui.grad(th.a, th.b, dp(14).toFloat())
            inner.addView(prev, Ui.lp(Ui.MATCH, dp(104)))
            val nm = Ui.tv(this, th.name, 15f, Color.WHITE, true)
            nm.setPadding(dp(4), dp(10), 0, dp(4))
            inner.addView(nm)
            card.addView(inner)
            val g = GradientDrawable()
            g.cornerRadius = dp(20).toFloat()
            g.setColor(Palette.CARD)
            if (i == cur) g.setStroke(dp(2), th.a)
            card.background = g
            if (i == cur) {
                val bd = FrameLayout(this)
                bd.background = Ui.oval(Color.WHITE)
                bd.addView(IconView(this, "check", 0xFF5B3FE0.toInt()), FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
                val bl = FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.END)
                bl.topMargin = dp(18)
                bl.rightMargin = dp(18)
                card.addView(bd, bl)
            }
            card.contentDescription = th.name + " theme"
            card.setOnClickListener {
                Store.setTheme(this, i)
                showMain(1)
            }
            val cl = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            if (i % 2 == 1) cl.leftMargin = dp(14)
            rowL!!.addView(card, cl)
        }
        return scroll(col)
    }

    // ---------- settings ----------

    private fun chev(): View {
        val v = IconView(this, "chev", Palette.MUTED)
        v.layoutParams = Ui.lp(dp(20), dp(20))
        return v
    }

    private fun row(title: String, sub: String?, right: View?, onClick: (() -> Unit)?): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(14), 0, dp(14))
        r.minimumHeight = dp(60)
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        tx.addView(Ui.tv(this, title, 16f, Color.WHITE))
        if (sub != null) tx.addView(Ui.tv(this, sub, 13f, Palette.MUTED))
        r.addView(tx, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        if (right is Toggle) r.addView(right, Ui.lp(dp(46), dp(28))) else if (right != null) r.addView(right)
        if (onClick != null) r.setOnClickListener { onClick() }
        return r
    }

    private fun group(rows: List<View>): View {
        val g = LinearLayout(this)
        g.orientation = LinearLayout.VERTICAL
        g.setPadding(dp(16), 0, dp(16), 0)
        g.background = Ui.rect(Palette.CARD, dp(20).toFloat())
        for ((i, r) in rows.withIndex()) {
            if (i > 0) {
                val d = View(this)
                d.setBackgroundColor(Palette.LINE)
                g.addView(d, Ui.lp(Ui.MATCH, 1))
            }
            g.addView(r, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        return g
    }

    private fun settingsTab(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(48), dp(20), dp(20))
        col.addView(Ui.tv(this, "Settings", 26f, Color.WHITE, true))
        val dm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val cn = ComponentName(this, AdminReceiver::class.java)
        val modes = arrayOf("Immediately", "After 1 minute", "After 5 minutes")

        val rows = ArrayList<View>()
        rows.add(row("Change PIN", null, chev()) { changePin() })
        rows.add(row("Security question", null, chev()) {
            showQuestion(null, { showMain(2) }) { qi, ans ->
                Store.setQuestion(this, qi, ans)
                toast("Security question saved")
                showMain(2)
            }
        })
        if (Ui.hasFinger(this)) {
            rows.add(row("Use fingerprint", null, Toggle(this, Store.finger(this)) { Store.setFinger(this, it) }, null))
        }
        val av = LinearLayout(this)
        av.gravity = Gravity.CENTER_VERTICAL
        av.addView(Ui.tv(this, modes[Store.autolock(this).coerceIn(0, 2)], 14f, Palette.MUTED))
        val cv = chev()
        av.addView(cv)
        rows.add(row("Auto-lock", null, av) {
            Store.setAutolock(this, (Store.autolock(this) + 1) % 3)
            showMain(2)
        })
        val adminOn = dm.isAdminActive(cn)
        rows.add(row("Uninstall protection", "Stops others from removing this app", Toggle(this, adminOn) { on ->
            if (on) {
                detour = true
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
                i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "This stops others from uninstalling App Lock.")
                startActivity(i)
            } else {
                try { dm.removeActiveAdmin(cn) } catch (e: Exception) { }
            }
        }, null))
        val g1 = Ui.lp(Ui.MATCH, Ui.WRAP)
        g1.topMargin = dp(16)
        col.addView(group(rows), g1)

        val about = ArrayList<View>()
        about.add(row("About", null, chev()) {
            AlertDialog.Builder(this)
                .setTitle("App Lock")
                .setMessage("Version 1.1\n\nYour PIN and settings stay only on this phone. This app has no internet access.")
                .setPositiveButton("OK", null)
                .show()
        })
        val g2 = Ui.lp(Ui.MATCH, Ui.WRAP)
        g2.topMargin = dp(16)
        col.addView(group(about), g2)
        return scroll(col)
    }

    private fun changePin() {
        pinScreen(null, "Enter current PIN", "Confirm it is you before changing.", false, null) { pad, p ->
            if (Ui.verify(this, pad, p)) {
                pinTwice(null, "Enter new PIN", "Choose a new 4-digit PIN.", { showMain(2) }) { np ->
                    Store.setPin(this, np)
                    toast("PIN changed")
                    showMain(2)
                }
            }
        }
        back = { showMain(2) }
    }
}
