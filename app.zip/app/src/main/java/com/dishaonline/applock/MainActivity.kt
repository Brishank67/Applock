package com.dishaonline.applock

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun col() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(24), dp(16), dp(16))
    }

    private fun label(s: String, size: Int) = TextView(this).apply {
        text = s
        textSize = size.toFloat()
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun hasUsage(): Boolean {
        val a = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return a.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        if (Store.hasPin(this)) showMain() else showSetup()
    }

    private fun showSetup() {
        val root = col()
        root.addView(label("Naya PIN set karo (4 se 6 digit)", 20))
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "PIN"
        }
        root.addView(et)
        root.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                val p = et.text.toString()
                if (p.length in 4..6) {
                    Store.setPin(this@MainActivity, p)
                    showMain()
                } else {
                    Toast.makeText(this@MainActivity, "4 se 6 digit ka PIN daalo", Toast.LENGTH_SHORT).show()
                }
            }
        })
        setContentView(root)
    }

    private fun showMain() {
        val usageOk = hasUsage()
        val overlayOk = Settings.canDrawOverlays(this)
        val root = col()
        root.addView(label("App Lock", 24))

        if (!usageOk) {
            root.addView(Button(this).apply {
                text = "1) Usage Access allow karo"
                setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            })
        }
        if (!overlayOk) {
            root.addView(Button(this).apply {
                text = "2) Display over other apps allow karo"
                setOnClickListener {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
                    )
                }
            })
        }
        if (usageOk && overlayOk) WatchService.start(this)

        root.addView(Switch(this).apply {
            text = "App Lock chalu"
            isChecked = Store.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Store.setEnabled(this@MainActivity, on) }
        })
        root.addView(CheckBox(this).apply {
            text = "Fingerprint se unlock"
            isChecked = Store.finger(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Store.setFinger(this@MainActivity, on) }
        })
        root.addView(label("Lock karne wale apps chuno:", 16))

        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
                val pkg = apps[p].first
                val name = apps[p].second
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(8), 0, dp(8))
                }
                val icon = ImageView(this@MainActivity)
                try { icon.setImageDrawable(pm.getApplicationIcon(pkg)) } catch (e: Exception) { }
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(
                    TextView(this@MainActivity).apply {
                        text = name
                        setPadding(dp(12), 0, dp(8), 0)
                    },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                )
                row.addView(Switch(this@MainActivity).apply {
                    isChecked = pkg in Store.locked(this@MainActivity)
                    setOnCheckedChangeListener { _, on -> Store.setLocked(this@MainActivity, pkg, on) }
                })
                return row
            }
        }
        root.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
