package com.dishaonline.applock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CancellationSignal
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView

class LockActivity : Activity() {
    private var pkg = ""
    private var cancel: CancellationSignal? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = Palette.BG_TOP
        window.navigationBarColor = Palette.BG
        WatchService.lockShowing = true
        pkg = intent.getStringExtra("pkg") ?: ""

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(Ui.dp(this, 24), Ui.dp(this, 40), Ui.dp(this, 24), Ui.dp(this, 20))
        root.background = Ui.bg()
        root.addView(Ui.brandHeader(this, 60, 26f))

        val t1 = Ui.tv(this, "App Locked", 22f, Color.WHITE, true)
        val l1 = Ui.lp(Ui.WRAP, Ui.WRAP)
        l1.topMargin = Ui.dp(this, 22)
        root.addView(t1, l1)
        val t2 = Ui.tv(this, "Enter your PIN to continue", 14f, Palette.MUTED)
        val l2 = Ui.lp(Ui.WRAP, Ui.WRAP)
        l2.topMargin = Ui.dp(this, 6)
        root.addView(t2, l2)

        var pad: PinPad? = null
        pad = PinPad(this) { p ->
            if (Ui.verify(this, pad!!, p)) unlock()
        }
        root.addView(pad)
        if (Ui.fingerOk(this)) root.addView(Ui.fingerRow(this) { askFinger() })

        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(root, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(sv)
        sv.post { askFinger() }
    }

    private fun askFinger() {
        cancel?.cancel()
        cancel = Ui.finger(this, "Unlock with fingerprint") { unlock() }
    }

    private fun unlock() {
        WatchService.unlockedPkg = pkg
        finishAndRemoveTask()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val h = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(h)
        finishAndRemoveTask()
    }

    override fun onStop() {
        super.onStop()
        if (!isFinishing) finishAndRemoveTask()
    }

    override fun onDestroy() {
        WatchService.lockShowing = false
        cancel?.cancel()
        super.onDestroy()
    }
}
