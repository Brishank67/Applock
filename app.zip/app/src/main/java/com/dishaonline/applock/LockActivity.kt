package com.dishaonline.applock

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.biometrics.BiometricPrompt
import android.os.Bundle
import android.os.CancellationSignal
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class LockActivity : Activity() {
    private var pkg = ""
    private var appName = ""
    private var cancel: CancellationSignal? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WatchService.lockShowing = true
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        pkg = intent.getStringExtra("pkg") ?: ""
        appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#1A237E"))
        }
        root.addView(TextView(this).apply {
            text = "$appName locked hai"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "PIN daalo"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.CENTER
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val p = s?.toString() ?: ""
                if (p.length >= 4 && Store.checkPin(this@LockActivity, p)) unlock()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) { }
            override fun onTextChanged(s: CharSequence?, st: Int, bf: Int, c: Int) { }
        })
        root.addView(et)
        root.addView(Button(this).apply {
            text = "Fingerprint"
            setOnClickListener { askFinger() }
        })
        setContentView(root)
        et.requestFocus()
        root.post { askFinger() }
    }

    private fun askFinger() {
        if (!Store.finger(this)) return
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) return
        try {
            val ex = mainExecutor
            val bp = BiometricPrompt.Builder(this)
                .setTitle("$appName unlock karo")
                .setNegativeButton("PIN use karo", ex) { _, _ -> }
                .build()
            cancel?.cancel()
            val cs = CancellationSignal()
            cancel = cs
            bp.authenticate(cs, ex, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) {
                    unlock()
                }
            })
        } catch (e: Exception) { }
    }

    private fun unlock() {
        WatchService.unlockedPkg = pkg
        finishAndRemoveTask()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val h = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(h)
        finishAndRemoveTask()
    }

    override fun onStop() {
        super.onStop()
        if (!isFinishing) finishAndRemoveTask()
    }

    override fun onDestroy() {
        WatchService.lockShowing = false
        cancel?.cancel()
        super.onDestroy()
    }
}
