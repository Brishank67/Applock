package com.dishaonline.applock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CancellationSignal
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

class LockActivity : Activity() {
    private var pkg = ""
    private var appName = ""
    private var cancel: CancellationSignal? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = Palette.BG
        window.navigationBarColor = Palette.BG
        WatchService.lockShowing = true
        pkg = intent.getStringExtra("pkg") ?: ""
        appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(Ui.dp(this, 32), Ui.dp(this, 56), Ui.dp(this, 32), Ui.dp(this, 24))
        root.background = Ui.bg(this)

        val icon = ImageView(this)
        try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (e: Exception) { }
        root.addView(icon, Ui.lp(Ui.dp(this, 76), Ui.dp(this, 76)))

        val t1 = Ui.tv(this, appName, 24f, Color.WHITE, true)
        t1.gravity = Gravity.CENTER
        val l1 = Ui.lp(Ui.WRAP, Ui.WRAP)
        l1.topMargin = Ui.dp(this, 18)
        root.addView(t1, l1)

        val t2 = Ui.tv(this, "Enter your PIN to unlock", 15f, Palette.MUTED)
        t2.gravity = Gravity.CENTER
        val l2 = Ui.lp(Ui.WRAP, Ui.WRAP)
        l2.topMargin = Ui.dp(this, 6)
        root.addView(t2, l2)

        var pad: PinPad? = null
        pad = PinPad(this, Ui.fingerOk(this), { askFinger() }, { p ->
            if (Ui.verify(this, pad!!, p)) unlock()
        })
        root.addView(pad)

        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(root, android.view.ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(sv)
        sv.post { askFinger() }
    }

    private fun askFinger() {
        cancel?.cancel()
        cancel = Ui.finger(this, "Unlock " + appName) { unlock() }
    }

    private fun unlock() {
        WatchService.unlockedPkg = pkg
        finishAndRemoveTask()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val h = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(h)
        finishAndRemoveTask()
    }

    override fun onStop() {
        super.onStop()
        if (!isFinishing) finishAndRemoveTask()
    }

    override fun onDestroy() {
        WatchService.lockShowing = false
        cancel?.cancel()
        super.onDestroy()
    }
}
